@echo off
call "%~dp0CHAY_EVENT_QA.cmd"
exit /b %errorlevel%
