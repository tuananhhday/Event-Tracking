@echo off
setlocal
cd /d "%~dp0"
title EventQA Portable - Choose mode
if not exist "runtime\node.exe" (
  echo Missing runtime\node.exe. Extract the entire ZIP first.
  pause
  exit /b 1
)
"runtime\node.exe" --version
if errorlevel 1 (
  echo Node could not run. Ask company IT to approve this portable runtime.
  pause
  exit /b 1
)
"runtime\node.exe" --env-file-if-exists=.env src\cli.mjs hub --open
if errorlevel 1 pause
