@echo off
call "%~dp0STOP_EVENT_QA.cmd"
exit /b %errorlevel%
