// EventQA shared client. Each mode page provides its own markup and hooks;
// this file owns polling, the guided flow, live evidence, rule building and reports.
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const short = (value, max = 120) => { const text = typeof value === 'string' ? value : JSON.stringify(value); return text === undefined ? '—' : text.length > max ? `${text.slice(0, max)}…` : text; };
  const clock = iso => iso ? new Date(iso).toLocaleTimeString('vi-VN', { hour12: false }) : '';
  const duration = ms => { const s = Math.max(0, Math.floor(ms / 1000)); return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; };
  const escapeRegex = text => text.replace(/[.*+?^${}()|[\]\\/]/g, '\\$&');
  const store = {
    get(key, fallback) { try { const raw = localStorage.getItem(key); return raw == null ? fallback : JSON.parse(raw); } catch { return fallback; } },
    set(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* private mode */ } },
  };

  const DEFAULT_VENDORS = ['ga4', 'ga4_server', 'insider'];
  const DEMO_CONTEXTS = {
    'TC-HOTEL-SEARCH-001': { search: { destination_name: 'Phú Quốc', adults: 2, nights: 1 } },
    'TC-MERCH-SEARCH-001': { search: { term: 'snack' } },
    'TC-INSIDER-DETAIL-001': { product: { id: 'SKU-001' } },
  };
  // GA4 Measurement Protocol parameters: transport metadata, not business fields.
  const GA4_PROTOCOL = new Set(['v', 'tid', 'gtm', 'gcd', 'npa', 'dma', 'dma_cps', 'cid', 'ul', 'sr', 'uaa', 'uab', 'uafvl', 'uamb', 'uam', 'uap', 'uapv', 'uaw', 'are', 'frm', 'pscdl', 'sid', 'sct', 'seg', 'dl', 'dr', 'dt', 'tfd', 'ec_mode', 'tag_exp', 'ngs', 'gcs', 'gcu', 'richsstsse', 'pae', 'ir', 'tt', 'apve', 'apvf', 'gtm_up', 'gcut', 'dp', 'ecid', 'en']);
  const ISSUE_TEXT = {
    EVENT_NAME_MISMATCH: 'Tên event không đúng đặc tả', LAYER_MISMATCH: 'Chọn sai dữ liệu trên website hoặc dữ liệu đã gửi',
    MISSING_EVENT: 'Chưa thấy event', DUPLICATE_EVENT: 'Event bị lặp', MISSING_FIELD: 'Thiếu thông tin bắt buộc', NULL_FIELD: 'Thông tin này đang trống',
    UNEXPECTED_FIELD: 'Có thông tin không được phép xuất hiện', VALUE_MISMATCH: 'Giá trị không đúng yêu cầu', DYNAMIC_VALUE_MISMATCH: 'Không giống thông tin đã nhập trên website', WRONG_TYPE: 'Sai kiểu dữ liệu',
    HTTP_ERROR: 'Request lỗi HTTP', REQUEST_FAILED: 'Request thất bại', TIMING_EXCEEDED: 'Quá thời gian cho phép', MISSING_TIMING: 'Thiếu mốc thời gian',
    OUT_OF_ORDER: 'Sai thứ tự', ORDER_PREDECESSOR_MISSING: 'Thiếu event đứng trước', MISSING_CONTEXT: 'Chưa có thông tin đã nhập trên website để so sánh',
    INVALID_RULE: 'Cách kiểm tra chưa hợp lệ', RULE_NEEDS_REVIEW: 'Cách kiểm tra chưa được xác nhận', LAYER_UNAVAILABLE: 'Chưa thu thập được loại dữ liệu này',
    VALUE_TOO_LARGE: 'Dữ liệu quá lớn để so sánh', REVIEW: 'Cần kiểm tra thêm', NO_EXPECTED_FIELDS: 'Chưa có yêu cầu để kiểm tra event này', INCOMPLETE_CAPTURE: 'Chưa thu được đầy đủ dữ liệu',
    NOT_FORWARDED: 'Website có thông tin này nhưng chưa gửi đi', NOT_SENT: 'Website đã tạo event nhưng chưa thấy gửi đi', PENDING_DELIVERY: 'Đang chờ website gửi event',
  };
  // Whether a pushed event left the browser (src/core/delivery.mjs).
  const vendorName = source => source === 'GA4' ? 'Google' : source === 'INSIDER' ? 'Insider' : 'server';
  const DELIVERY_PILL = { sent: s => ['PASS', `Đã gửi lên ${vendorName(s)}`], not_sent: () => ['FAIL', 'Không gửi lên server'], pending: () => ['REVIEW', 'Đang chờ gửi'], unverified: () => ['', 'Trước khi thu thập'] };
  const deliveryPill = (status, source) => DELIVERY_PILL[status] ? (([cls, label]) => `<span class="pill ${cls}">${esc(label)}</span>`)(DELIVERY_PILL[status](source)) : '';
  const VERDICT_TEXT = { PASS: 'PASS', FAIL: 'FAIL', REVIEW: 'REVIEW', NOT_EXECUTED: 'Chưa chạy' };
  const LAYER_TEXT = { JS_QUEUE: 'JS queue', TRACKING_REQUEST: 'Request' };
  // Where a specification row comes from: Excel sheet!row, or "Nhập tay" for an event typed in the app.
  const whereSpec = (sheet, row) => row == null || row === '' ? String(sheet ?? '') : `${sheet ?? ''}!${row}`;
  const SOURCE_TEXT = { GA4: 'GA4', INSIDER: 'Insider' };
  const FILE_TEXT = { xlsx: ['Excel', 'Báo cáo và bằng chứng đối chiếu'], html: ['HTML', 'Bảng đối chiếu có lọc và xem chi tiết'], json: ['JSON', 'Comparison đầy đủ'], bugs: ['Bug (Markdown)', 'Dán vào Jira thủ công'], api_calls: ['API Request/Response', 'api-calls.jsonl: mỗi dòng một lời gọi API'], automation: ['Luồng tự động', 'Tiến độ và kết quả thao tác'], api_html: ['API · HTML', 'Toàn bộ API và chi tiết trong một file'], api_json: ['API · JSON', 'Request/response của phiên'], api_xlsx: ['API · Excel', 'Danh sách và trường chi tiết'], tp2_html: ['TP2 ↔ API · HTML', 'Dữ liệu giải mã và đối chiếu'], tp2_json: ['TP2 ↔ API · JSON', 'Dữ liệu giải mã và đối chiếu'], tp2_xlsx: ['TP2 ↔ API · Excel', 'Dữ liệu giải mã và đối chiếu'] };
  const OPS = [['eq', 'bằng'], ['exists', 'có mặt'], ['type', 'kiểu'], ['regex', 'regex'], ['ref', 'lấy từ context'], ['one_of', 'một trong'], ['not_exists', 'không được có'], ['ignore', 'bỏ qua']];
  for (const format of ['html', 'xlsx', 'json']) FILE_TEXT[`tracking_${format}`] = [`Danh sách tracking · ${format.toUpperCase()}`, 'Tên event, số lần xuất hiện, trang và bằng chứng thực tế'];

  const ui = { state: null, stateEpoch: 0, busy: null, stopped: false, offline: false, selectedCase: null, contexts: new Map(),
    sig: {}, details: new Map(), loadingDetails: new Set(), expandedGroup: null, casesKey: null, holdUntil: 0, holdTimer: null, groupFilter: null, openEvents: new Set(), seenEvents: new Set(), phase: null, tab: 'events', view: 'activity', marker: null,
    activity: [], activityVersion: null, activityNext: null, activityTotal: 0, activitySelected: null,
    hooks: {}, token: '', mode: '', vendorsRendered: false, builder: null, pushes: [], pushVersion: null, pushLoading: false,
    apiCalls: [], apiCallsMeta: null, apiCallsVersion: null, apiCallsLoading: false, apiCallDetails: new Map() };
  const siteKey = () => `eventqa:${ui.mode}:site`;

  // ---- feedback ---------------------------------------------------------
  function toast(message, kind = '') {
    const host = $('toasts'); if (!host) return;
    while (host.children.length >= 3) host.firstElementChild.remove();
    const item = document.createElement('div'); item.className = `toast ${kind}`; item.setAttribute('role', kind === 'error' ? 'alert' : 'status'); item.textContent = message;
    host.append(item); setTimeout(() => item.remove(), kind === 'error' ? 7000 : 3500);
  }
  function showError(message) {
    const box = $('error'); if (!box) return;
    box.textContent = message || ''; box.classList.toggle('hidden', !message);
    if (message) toast(message, 'error');
  }

  // ---- server -----------------------------------------------------------
  async function api(path, data = {}, label = path) {
    ui.busy = label; render(); showError('');
    try {
      const response = await fetch(`/api/${path}`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-EventQA-Token': ui.token }, body: JSON.stringify(data) });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || `Thao tác thất bại (HTTP ${response.status}).`);
      if (result.mode) { ui.stateEpoch++; ui.state = result; }
      return result;
    } catch (error) { showError(error.message); error.shown = true; throw error; }
    finally { ui.busy = null; if (path.startsWith('comparison/')) ui.holdUntil = 0; await refresh(); render(); }
  }
  async function refresh() {
    if (ui.stopped || ui.refreshing || document.hidden) return;
    ui.refreshing = true;
    const epoch = ui.stateEpoch;
    try {
      const response = await fetch('/api/state' + (ui.view === 'stream' ? '' : '?compact=1'), { cache: 'no-store', signal: AbortSignal.timeout(10000) });
      if (!response.ok) throw new Error();
      const state = await response.json(); if (epoch === ui.stateEpoch) ui.state = state; setOffline(false);
    } catch { setOffline(true); }
    finally { ui.refreshing = false; }
    render();
  }
  async function fetchEvent(id) {
    const local = ui.state?.events.find(e => e.evidence_id === id); if (local && !ui.state?.eventsCompact) return local;
    const response = await fetch(`/api/event?id=${encodeURIComponent(id)}`); if (!response.ok) return null;
    return (await response.json()).event;
  }
  function setOffline(offline) {
    if (ui.offline === offline) return; ui.offline = offline;
    const conn = $('conn'); if (conn) { conn.classList.toggle('offline', offline); conn.textContent = offline ? 'Mất kết nối ứng dụng' : 'Đã kết nối'; }
  }
  const run = fn => () => Promise.resolve().then(fn).catch(error => { if (!error?.shown) showError(error?.message || String(error)); });

  // ---- derived state ----------------------------------------------------
  function phaseOf(s) {
    if (!s) return 'loading';
    if (s.closing) return 'closing';
    if (s.currentStep) return 'recording';
    if (s.running) return 'running';
    if (s.session) return 'finished';
    return 'idle';
  }
  const caseById = id => ui.state?.cases.find(c => c.id === id);
  const caseNeedsReview = c => !!c && (c.needs_review || (c.rules || []).some(r => r.needs_review));
  const latestResult = caseId => (ui.state?.results || []).filter(r => r.test_case_id === caseId && r.step_id).at(-1);
  const afterMarker = e => !ui.marker || Date.parse(e.captured_at) >= ui.marker;

  // ---- site configuration (URL, vendors, endpoints) -------------------------
  // GA4 and Insider are what QC checks: they come first; GA4 server-side and other vendors sit under "Nâng cao".
  const MAIN_VENDORS = ['ga4', 'insider'];
  function renderVendors(s) {
    const host = $('vendors'); if (!host || ui.vendorsRendered || !s.vendors) return;
    const saved = store.get(siteKey(), {});
    const chosen = new Set(saved.vendors || DEFAULT_VENDORS);
    const box = ([key, vendor]) => `<label class="check"><input type="checkbox" data-vendor="${esc(key)}" ${chosen.has(key) ? 'checked' : ''}> ${esc(vendor.label)}</label>`;
    const vendors = Object.entries(s.vendors);
    host.innerHTML = vendors.filter(([key]) => MAIN_VENDORS.includes(key)).map(box).join('');
    ($('vendors-more') || host).insertAdjacentHTML('beforeend', vendors.filter(([key]) => !MAIN_VENDORS.includes(key)).map(box).join(''));
    ui.vendorsRendered = true;
  }
  function endpointPatterns() {
    const vendors = ui.state?.vendors || {};
    const patterns = $$('[data-vendor]').filter(box => box.checked).flatMap(box => vendors[box.dataset.vendor]?.patterns || []);
    const custom = ($('patterns')?.value || '').split('\n').map(p => p.trim()).filter(Boolean);
    for (const pattern of custom) { try { new RegExp(pattern); } catch { throw new Error(`Regex endpoint không hợp lệ: ${pattern}`); } }
    return [...new Set([...patterns, ...custom])];
  }
  // API Request/Response log: on/off and the API hosts (one regex per line, matched against host + path).
  function apiLogOptions() {
    const logApi = $('log-api')?.checked ?? true;
    const apiLogPatterns = ($('api-patterns')?.value || '').split('\n').map(line => line.trim()).filter(Boolean);
    for (const pattern of apiLogPatterns) { try { new RegExp(pattern); } catch { throw new Error(`Mẫu host API không hợp lệ: ${pattern}`); } }
    return { logApi, ...(apiLogPatterns.length ? { apiLogPatterns } : {}) };
  }
  function saveSite() {
    const saved = store.get(siteKey(), {});
    const url = $('url')?.value.trim();
    const recent = [url, ...(saved.recent || [])].filter((u, i, list) => u && !u.includes('/demo') && list.indexOf(u) === i).slice(0, 6);
    store.set(siteKey(), { ...saved, url, recent, browser: $('browser')?.value, vendors: $$('[data-vendor]').filter(b => b.checked).map(b => b.dataset.vendor), custom: $('patterns')?.value || '', compareApi: $('compare-api')?.checked ?? true, logApi: $('log-api')?.checked ?? true, apiPatterns: $('api-patterns')?.value ?? '' });
    renderRecent();
  }
  function renderRecent() {
    const host = $('recent'); if (!host) return;
    const recent = store.get(siteKey(), {}).recent || [];
    host.innerHTML = recent.map(u => `<button type="button" class="chip" data-url="${esc(u)}" data-lock-running title="${esc(u)}">${esc(hostOf(u))}</button>`).join('');
    host.classList.toggle('hidden', !recent.length);
  }
  function restoreSite() {
    const saved = store.get(siteKey(), {});
    if ($('url') && saved.url) $('url').value = saved.url;
    if ($('patterns') && saved.custom) $('patterns').value = saved.custom;
    if ($('compare-api') && saved.compareApi === false) $('compare-api').checked = false;
    if ($('log-api') && saved.logApi === false) $('log-api').checked = false;
    if ($('api-patterns') && typeof saved.apiPatterns === 'string' && saved.apiPatterns.trim()) $('api-patterns').value = saved.apiPatterns;
    if (saved.browser) setBrowser(saved.browser);
    renderRecent();
  }
  function setBrowser(name) { if ($('browser')) $('browser').value = name; for (const b of $$('[data-browser]')) b.setAttribute('aria-pressed', String(b.dataset.browser === name)); }

  // ---- context templates -------------------------------------------------
  function contextTemplate(testCase) {
    if (!testCase) return {};
    if (DEMO_CONTEXTS[testCase.id]) return structuredClone(DEMO_CONTEXTS[testCase.id]);
    const template = {};
    for (const rule of testCase.rules || []) for (const field of Object.values(rule.fields || {})) {
      if (field?.op !== 'ref' || typeof field.value !== 'string' || !field.value.startsWith('context.')) continue;
      const parts = field.value.slice('context.'.length).split('.'); let node = template;
      parts.forEach((part, index) => { if (index === parts.length - 1) node[part] ??= ''; else node = node[part] = typeof node[part] === 'object' && node[part] ? node[part] : {}; });
    }
    return template;
  }
  function emptyLeaves(value, prefix = '') {
    if (value === '' || value === null) return [prefix];
    if (!value || typeof value !== 'object') return [];
    return Object.entries(value).flatMap(([key, child]) => emptyLeaves(child, prefix ? `${prefix}.${key}` : key));
  }
  function parseJson(id, errorId) {
    const area = $(id); const error = $(errorId);
    try { const value = JSON.parse(area.value || '{}'); area.classList.remove('invalid'); if (error) error.textContent = ''; return { ok: true, value }; }
    catch (e) { area.classList.add('invalid'); if (error) error.textContent = `JSON chưa hợp lệ: ${e.message}`; return { ok: false, message: e.message }; }
  }
  function validateContext() {
    const parsed = parseJson('context', 'context-error'); const hint = $('context-hint');
    if (!parsed.ok || !hint) return parsed;
    const empty = emptyLeaves(parsed.value);
    hint.textContent = empty.length ? `Cần điền giá trị thực tế: ${empty.map(p => `context.${p}`).join(', ')}` : '';
    hint.classList.toggle('hidden', !empty.length);
    return parsed;
  }

  // ---- case selection ---------------------------------------------------
  function selectCase(id, { force = false } = {}) {
    if (!force && ui.selectedCase === id) return;
    if (ui.selectedCase && $('context')) ui.contexts.set(ui.selectedCase, $('context').value);
    ui.selectedCase = id; const testCase = caseById(id);
    if ($('context')) { $('context').value = ui.contexts.get(id) ?? JSON.stringify(contextTemplate(testCase), null, 2); validateContext(); }
    loadRuleEditor(testCase);
    ui.sig.cases = null; render();
  }
  function resetSelection() { ui.contexts.clear(); ui.selectedCase = null; ui.sig.cases = null; render(); }
  function loadRuleEditor(testCase) {
    if (!$('case-json')) return;
    $('case-json').value = JSON.stringify(testCase || {}, null, 2);
    $('case-json').classList.remove('invalid'); if ($('case-json-error')) $('case-json-error').textContent = '';
    if ($('approve')) $('approve').checked = !!testCase && !caseNeedsReview(testCase);
    if ($('rule-title')) $('rule-title').textContent = testCase ? testCase.id : '';
  }
  function renderCases(s) {
    const host = $('cases'); if (!host) return;
    if (!s.cases.some(c => c.id === ui.selectedCase)) { const first = s.cases[0]?.id ?? null; if (first !== ui.selectedCase) { ui.selectedCase = null; if (first) return selectCase(first); } }
    const locked = !!s.currentStep;
    $('no-cases')?.classList.toggle('hidden', s.cases.length > 0);
    $('with-cases')?.classList.toggle('hidden', !s.cases.length);
    const sig = JSON.stringify([s.cases.map(c => [c.id, c.name, caseNeedsReview(c)]), ui.selectedCase, locked, s.currentStep?.test_case_id, s.results.map(r => [r.step_id, r.verdict])]);
    if (sig === ui.sig.cases) return; ui.sig.cases = sig;
    host.innerHTML = s.cases.map(c => {
      const last = latestResult(c.id); const active = s.currentStep?.test_case_id === c.id;
      const badge = active ? '<span class="pill FAIL">● Đang ghi</span>' : last ? `<span class="pill ${esc(last.verdict)}">${esc(VERDICT_TEXT[last.verdict] || last.verdict)}</span>` : '<span class="pill">Chưa chạy</span>';
      return `<button type="button" class="case" data-case="${esc(c.id)}" aria-pressed="${c.id === ui.selectedCase}" ${locked ? 'disabled' : ''}>
        <span class="case-main"><strong>${esc(c.name || c.id)}</strong><small>${esc(c.id)} · ${(c.rules || []).length} rule${caseNeedsReview(c) ? ' · <span class="pill warn">Cần duyệt</span>' : ''}</small></span>${badge}</button>`;
    }).join('');
  }

  // ---- flow (stepper) ---------------------------------------------------
  function stageForPhase(phase) { return { idle: 'session', loading: 'session', running: null, recording: null, finished: 'report', closing: 'report' }[phase]; }
  function setStage(name, open) { const stage = document.querySelector(`[data-stage="${name}"]`); if (stage) { stage.classList.toggle('open', open); stage.querySelector('.stage-head')?.setAttribute('aria-expanded', String(open)); } }
  function renderFlow(s, phase) {
    if (phase !== ui.phase) {
      const target = stageForPhase(phase);
      for (const stage of $$('[data-stage]')) setStage(stage.dataset.stage, stage.dataset.stage === target);
      ui.phase = phase;
    }
    const current = stageForPhase(phase);
    const done = { spec: s.cases.length > 0, session: !!s.session, step: s.results.some(r => r.step_id), report: !!s.exported };
    for (const stage of $$('[data-stage]')) { stage.classList.toggle('current', stage.dataset.stage === current); stage.classList.toggle('done', done[stage.dataset.stage] && stage.dataset.stage !== current); }
    const review = s.cases.filter(caseNeedsReview).length;
    const source = { reviewed: 'rule đã lưu', file: 'từ file', demo: 'demo' }[s.specSource] || '';
    setText('sum-spec', s.cases.length ? `${s.cases.length} case ${source}${review ? ` · ${review} cần duyệt` : ''}` : 'Chưa có · thu thập tự do');
    setText('sum-session', s.running ? `Đang chạy · ${s.session.browser || ''} · ${hostOf(s.session.target_url)}` : s.session ? `Phiên ${s.session.status === 'COMPLETED' ? 'đã kết thúc' : 'đã dừng'}` : 'Nhập URL và mở trình duyệt test');
    const executed = s.results.filter(r => r.step_id).length;
    setText('sum-step', s.currentStep ? `Đang ghi: ${caseById(s.currentStep.test_case_id)?.name || s.currentStep.test_case_id}` : s.cases.length ? `${executed} bước đã chạy` : 'Tạo rule từ event thật để bắt đầu');
    setText('sum-report', s.exported ? 'Báo cáo sẵn sàng tải' : s.running ? 'Kết thúc phiên để xuất' : 'Chưa xuất');
  }
  const hostOf = url => { try { return new URL(url).host; } catch { return url || ''; } };
  const setText = (id, text) => { const el = $(id); if (el && el.textContent !== text) el.textContent = text; };

  // ---- session bar ------------------------------------------------------
  function renderBar(s, phase) {
    const bar = $('sessionbar'); if (!bar) return;
    bar.classList.toggle('recording', phase === 'recording');
    $('phase').className = `phase ${phase}`;
    const explore = phase === 'running' && !s.cases.length;
    setText('phase-label', { loading: 'Đang tải…', idle: 'Chưa mở website', running: s.specCoverage?.selection.active ? 'Đang đối chiếu luồng' : 'Đang thu thập event', recording: 'Đang chạy tự động', finished: s.session?.status === 'COMPLETED' ? 'Phiên đã kết thúc' : 'Phiên đã dừng', closing: 'Đang tắt…' }[phase]);
    const meta = [];
    if (s.session) meta.push(`<span>Website <b>${esc(hostOf(s.session.target_url))}</b></span>`);
    if (phase === 'recording') {
      meta.push(`<span>Case <b>${esc(caseById(s.currentStep.test_case_id)?.name || s.currentStep.test_case_id)}</b></span>`);
      meta.push(`<span>Thời gian <b data-elapsed="${esc(s.currentStep.started_at)}">${duration(Date.now() - Date.parse(s.currentStep.started_at))}</b></span>`);
      meta.push(`<span>Event trong bước <b>${s.stepEventCount ?? 0}</b></span>`);
    } else if (s.session) meta.push(`<span>Bằng chứng <b>${s.eventCount}</b></span><span>Loại event <b>${s.eventSummary?.length ?? 0}</b></span>`);
    else meta.push('<span>Nhập URL website thật ở bước 1 rồi mở trình duyệt test.</span>');
    if (ui.marker && s.running) meta.push(`<span>Mốc <b>${esc(clock(new Date(ui.marker).toISOString()))}</b></span>`);
    const metaHtml = meta.join(''); if ($('session-meta').innerHTML !== metaHtml) $('session-meta').innerHTML = metaHtml;

    const primary = $('bar-primary'), secondary = $('bar-secondary');
    const action = {
      idle: [ui.hooks.startLabel || 'Mở trình duyệt test', 'start', 'primary'], finished: ['Mở phiên mới', 'start', 'primary'],
      running: explore ? ['Xem event thu thập', 'view-events', 'primary'] : s.specCoverage?.selection.attempt ? ['Xem đối chiếu', 'view-spec', 'primary'] : ['Chọn luồng kiểm tra', 'select-flow', 'primary'],
      recording: ['Xem đối chiếu', 'view-spec', 'primary'], loading: ['…', null, 'primary'], closing: ['Đang tắt…', null, 'primary'],
    }[phase];
    primary.textContent = ui.busy ? 'Đang xử lý…' : action[0]; primary.dataset.action = action[1] || ''; primary.className = `btn ${action[2]}`;
    primary.disabled = !!ui.busy || !action[1] || (action[1] === 'step-start' && !ui.selectedCase);
    const second = { running: ['Kết thúc', 'finish-only'], recording: ['Kết thúc', 'finish-only'] }[phase];
    secondary.classList.toggle('hidden', !second);
    if (second) { secondary.textContent = second[0]; secondary.dataset.action = second[1]; secondary.disabled = ui.busy === 'finish-only' || !!ui.state?.closing; }
  }
  function tickTimers() { for (const el of $$('[data-elapsed]')) el.textContent = duration(Date.now() - Date.parse(el.dataset.elapsed)); }

  // ---- results ----------------------------------------------------------
  function issueHtml(issue) {
    const rows = [];
    if (issue.path) rows.push(`<span>Trường</span><code>${esc(issue.path)}</code>`);
    if (issue.expected !== undefined) rows.push(`<span>Mong đợi</span><code>${esc(short(issue.expected))}</code>`);
    if (issue.actual !== undefined) rows.push(`<span>Thực tế</span><code>${esc(short(issue.actual))}</code>`);
    return `<div class="issue"><b>${esc(ISSUE_TEXT[issue.code] || issue.code || 'Lệch')}</b> <small class="hint">${esc(issue.code || '')}</small><div class="diff">${rows.join('')}</div>
      ${issue.evidence_id ? `<button type="button" class="evlink" data-evidence="${esc(issue.evidence_id)}">${esc(issue.evidence_id)}</button>` : ''}</div>`;
  }
  function renderResults(s) {
    const host = $('results'); if (!host) return;
    const sig = JSON.stringify([s.results, s.specCoverage?.totals, s.specCoverage?.selection, s.cases.map(c => [c.id, c.name])]); if (sig === ui.sig.results) return; ui.sig.results = sig;
    const executed = s.results.filter(r => r.step_id).reverse();
    const pending = s.results.filter(r => !r.step_id);
    const steps = new Map((s.steps || []).map(step => [step.id, step]));
    const notRun = pending.length ? `<p class="hint">Chưa chạy:</p><div class="not-run">${pending.map(r => `<span class="pill">${esc(caseById(r.test_case_id)?.name || r.test_case_id)}</span>`).join('')}</div>` : '';
    if (!executed.length) {
      host.innerHTML = (s.cases.length
        ? `<div class="empty"><strong>${s.specCoverage?.selection.attempt ? 'Kết quả đối chiếu theo luồng' : 'Chọn luồng để bắt đầu đối chiếu'}</strong>${s.specCoverage?.selection.attempt ? `Luồng ${esc(s.specCoverage.selection.attempt.flow)} · Khớp ${s.specCoverage.totals.match} · Lệch ${s.specCoverage.totals.mismatch}. Mở bảng đối chiếu để xem từng event.` : 'Nhập đặc tả, chọn luồng rồi thao tác trên website. Kết quả cập nhật trực tiếp.'}<button type="button" class="btn primary" data-action="view-spec">Mở bảng đối chiếu</button></div>`
        : '<div class="empty"><strong>Chưa có đặc tả để đối chiếu</strong>Nhập file đặc tả hoặc tạo rule từ event thật.</div>');
      return;
    }
    host.innerHTML = executed.map(result => {
      const testCase = caseById(result.test_case_id); const step = steps.get(result.step_id);
      const rows = (result.results || []).map(rule => `<tr><td><b>${esc(rule.event_name)}</b><br><small class="hint">${esc(rule.source || '')}</small></td>
        <td><span class="pill layer">${esc(LAYER_TEXT[rule.layer] || rule.layer)}</span></td>
        <td><span class="pill ${esc(rule.verdict)}">${esc(VERDICT_TEXT[rule.verdict] || rule.verdict)}</span></td>
        <td>${(rule.issues || []).map(issueHtml).join('') || `<span class="hint">Khớp ${(rule.checks || []).length} kiểm tra</span>${(rule.evidence_ids || []).slice(0, 1).map(id => `<br><button type="button" class="evlink" data-evidence="${esc(id)}">${esc(id)}</button>`).join('')}`}</td></tr>`).join('');
      return `<article class="result ${esc(result.verdict)}"><div class="result-head"><div class="name"><strong>${esc(testCase?.name || result.test_case_id)}</strong>
        <small>${esc(result.test_case_id)} · ${esc(clock(step?.started_at))}${step?.status && step.status !== 'COMPLETED' ? ` · ${esc(step.status)}` : ''}</small></div>
        ${result.warning ? '<span class="pill warn">Bước chưa hoàn tất</span>' : ''}<span class="pill ${esc(result.verdict)}">${esc(VERDICT_TEXT[result.verdict] || result.verdict)}</span></div>
        <div class="table-scroll"><table class="checks"><thead><tr><th>Event</th><th>Tầng</th><th>Kết quả</th><th>Chi tiết / bằng chứng</th></tr></thead><tbody>${rows || '<tr><td colspan="4" class="hint">Case chưa có rule.</td></tr>'}</tbody></table></div>
        ${result.ai_note ? `<p class="ai-note"><b>Gợi ý AI${result.ai_routing?.model ? ` · ${esc(result.ai_routing.model)}` : ''}</b>${esc(result.ai_note)}</p>` : ''}</article>`;
    }).join('') + notRun;
  }

  // ---- event detail ---------------------------------------------------------
  // Where an event's business parameters live, per vendor and layer. The base is the path
  // prefix the specification uses for the same fields.
  function eventParams(e) {
    const p = e.payload && typeof e.payload === 'object' ? e.payload : {};
    if (e.source === 'INSIDER' && e.layer === 'JS_QUEUE') {
      if (p.type === 'custom_event') return { base: 'value.0.event_parameters', params: p.value?.[0]?.event_parameters ?? {} };
      return { base: 'value', params: p.value && typeof p.value === 'object' && !Array.isArray(p.value) ? p.value : p.value !== undefined ? { value: p.value } : {} };
    }
    if (e.source === 'INSIDER' && e.layer === 'TRACKING_REQUEST' && p.event_params) return { base: 'event_params', params: p.event_params };
    const { event: _event, ...rest } = p;
    return { base: '', params: rest };
  }
  const isObjectList = value => Array.isArray(value) && value.length > 0 && value.every(item => item && typeof item === 'object' && !Array.isArray(item));
  // Flattens parameters to dotted paths; lists of objects (items, products) are kept whole for a table.
  function paramRows(params, prefix = '', out = [], depth = 0) {
    for (const [key, value] of Object.entries(params)) {
      const path = prefix ? `${prefix}.${key}` : key;
      if (isObjectList(value)) out.push({ path, list: value });
      else if (value && typeof value === 'object' && !Array.isArray(value) && depth < 4 && Object.keys(value).length) paramRows(value, path, out, depth + 1);
      else out.push({ path, value });
    }
    return out;
  }
  const formatValue = value => value === null ? '<span class="hint">null</span>' : value === undefined ? '<span class="hint">—</span>'
    : typeof value === 'string' ? (value === '' ? '<span class="hint">(rỗng)</span>' : esc(short(value, 160)))
    : Array.isArray(value) ? `<code>${esc(short(value, 160))}</code>` : `<code>${esc(String(value))}</code>`;
  function specMark(specPath, spec) {
    if (!spec) return '';
    const issue = spec.issues.find(i => i.path === specPath);
    if (issue) return `<span class="pill ${issue.verdict === 'FAIL' ? 'FAIL' : 'REVIEW'}">${esc(ISSUE_TEXT[issue.code] || issue.code)}</span>${issue.expected !== undefined && issue.code !== 'MISSING_FIELD' ? `<br><small class="hint">Mong đợi: ${esc(short(issue.expected, 60))}</small>` : ''}`;
    const op = spec.fields?.[specPath];
    if (op === 'ignore') return '<span class="hint">bỏ qua</span>';
    if (op) return '<span class="pill PASS">✓ Đúng</span>';
    return '<span class="hint">ngoài đặc tả</span>';
  }
  const FIRING_STATUS = { PASS: ['PASS', '✓'], WARN: ['REVIEW', '⚠'], FAIL: ['FAIL', '✗'] };
  const RULE_TEXT = { INSIDER_INIT: 'Insider: init sau dữ liệu trang', DELIVERED: 'Đã gửi lên server', CUSTOM_EVENT_SHAPE: 'Cấu trúc custom_event', DATE_PAIR: 'Cặp ngày ISO + _str',
    DESTINATION_PAIR: 'destination + destination_id', DUPLICATE: 'Không bắn trùng', ECOMMERCE_RESET: 'ecommerce: null trước event', ECOMMERCE_ITEMS: 'items đủ item_id/item_name', COUPON_ACTION: 'coupon action hợp lệ' };
  function firingHtml(checks) {
    if (!checks?.length) return '';
    const ordered = [...checks].sort((a, b) => ['FAIL', 'WARN', 'PASS'].indexOf(a.status) - ['FAIL', 'WARN', 'PASS'].indexOf(b.status));
    return `<div class="list-title"><b>Cách bắn</b></div><table class="params"><tbody>${ordered.map(check => { const [cls, icon] = FIRING_STATUS[check.status]; return `<tr><td><span class="pill ${cls}">${icon} ${esc(RULE_TEXT[check.rule] || check.rule)}</span></td><td>${esc(check.message)}${check.evidence_id ? ` <button type="button" class="evlink" data-evidence="${esc(check.evidence_id)}">xem</button>` : ''}</td></tr>`; }).join('')}</tbody></table>`;
  }
  function eventDetailHtml(e, spec, firing) {
    const { base, params } = eventParams(e);
    const rows = paramRows(params).filter(row => !/^gtm\./.test(row.path));
    const full = path => base ? `${base}.${path}` : path;
    const pageUrl = (() => { try { const u = new URL(e.page?.url); return u.host + u.pathname; } catch { return e.page?.url || ''; } })();
    const head = `<div class="ev-head"><div><span class="ev-title">${esc(e.event_name)}</span>
        <span class="pill layer">${esc(LAYER_TEXT[e.layer] || e.layer)}</span> <span class="pill">${esc(e.source)}</span>
        <div class="hint">${esc(clock(e.captured_at))} · ${esc(pageUrl)}${e.network?.status ? ` · HTTP ${esc(e.network.status)}` : ''}</div></div>
      ${spec ? `<div class="ev-spec"><span class="pill ${spec.verdict}">${spec.verdict === 'PASS' ? 'Chưa thấy lỗi' : spec.verdict === 'FAIL' ? 'Có lỗi' : 'Cần kiểm tra thêm'}</span><div class="hint">Đặc tả #${esc(spec.stt)} · ${esc(spec.flow)}</div></div>`
        : (ui.state?.cases.length ? '<div class="ev-spec"><span class="pill warn">Ngoài đặc tả</span></div>' : '')}</div>`;
    const scalar = rows.filter(row => !row.list);
    const lists = rows.filter(row => row.list);
    const scalarHtml = scalar.length ? `<table class="params"><thead><tr><th>Tham số</th><th>Giá trị</th>${spec ? '<th>So với đặc tả</th>' : ''}</tr></thead><tbody>${scalar.map(row => `<tr><td><code>${esc(row.path)}</code></td><td>${formatValue(row.value)}</td>${spec ? `<td>${specMark(full(row.path), spec)}</td>` : ''}</tr>`).join('')}</tbody></table>`
      : '<p class="hint">Event không có tham số.</p>';
    const listHtml = lists.map(({ path, list }) => {
      const columns = [...new Set(list.slice(0, 20).flatMap(item => Object.keys(item)))].slice(0, 16);
      const header = columns.map(column => { const mark = spec ? spec.issues.find(i => i.path === full(`${path}.0.${column}`)) : null; return `<th${mark ? ' class="bad"' : ''}>${esc(column)}${mark ? ' ⚠' : ''}</th>`; }).join('');
      // Judged on every key of the first item, not on the columns that fit in the table.
      const firstKeys = new Set(Object.keys(list[0]));
      const missing = spec ? Object.keys(spec.fields || {}).filter(p => p.startsWith(full(`${path}.0.`)) && !firstKeys.has(p.slice(full(`${path}.0.`).length)) && !p.slice(full(`${path}.0.`).length).includes('.')) : [];
      const title = `<div class="list-title"><code>${esc(path)}</code> · ${list.length} mục${missing.length ? ` · <span class="pill FAIL">Thiếu ${missing.map(m => esc(m.split('.').at(-1))).join(', ')}</span>` : ''}</div>`;
      // A few items (cart, checkout) read best one field per line; long lists stay a scrollable table.
      if (list.length <= 3) return title + list.map((item, index) => `<table class="params"><thead><tr><th>Mục ${index + 1}</th><th>Giá trị</th>${spec ? `<th>${index === 0 ? 'So với đặc tả' : ''}</th>` : ''}</tr></thead><tbody>${paramRows(item).map(row => `<tr><td><code>${esc(row.path)}</code></td><td>${row.list ? `<code>${esc(short(row.list, 160))}</code>` : formatValue(row.value)}</td>${spec ? `<td>${index === 0 ? specMark(full(`${path}.0.${row.path}`), spec) : ''}</td>` : ''}</tr>`).join('')}</tbody></table>`).join('');
      return `${title}
        <div class="table-scroll"><table class="params items"><thead><tr><th>#</th>${header}</tr></thead><tbody>${list.slice(0, 20).map((item, index) => `<tr><td>${index + 1}</td>${columns.map(column => `<td>${formatValue(item[column] && typeof item[column] === 'object' ? JSON.stringify(item[column]) : item[column])}</td>`).join('')}</tr>`).join('')}</tbody></table></div>${list.length > 20 ? `<p class="hint">+${list.length - 20} mục khác (xem JSON gốc)</p>` : ''}`;
    }).join('');
    // Fields the specification expects but the event does not carry at all.
    const absent = spec ? spec.issues.filter(i => i.code === 'MISSING_FIELD' && !rows.some(row => full(row.path) === i.path) && !/\.0\./.test(i.path)) : [];
    const absentHtml = absent.length ? `<div class="list-title"><span class="pill FAIL">Thiếu so với đặc tả</span> ${absent.map(i => `<code>${esc(base && i.path.startsWith(`${base}.`) ? i.path.slice(base.length + 1) : i.path)}</code>`).join(', ')}</div>` : '';
    const note = spec?.notes ? `<p class="hint">Ghi chú đặc tả: ${esc(spec.notes)}</p>` : '';
    const contract = spec ? `<p><b>Event Name trong đặc tả:</b> ${esc(spec.event_name)} · ${esc(whereSpec(spec.provenance?.sheet, spec.provenance?.row))}<br>${esc(spec.description)}</p><button type="button" class="btn small" data-spec-detail="${esc(spec.case_id)}">Xem chi tiết đặc tả</button>` : '';
    return `${head}${contract}${firingHtml(firing)}${absentHtml}${scalarHtml}${listHtml}${note}
      <div class="row" style="margin:10px 0 0">${e.network?.phase && e.network.phase !== 'request' ? '' : `<button type="button" class="btn small primary shrink" data-build="${esc(e.evidence_id)}">Tạo rule từ event này</button>`}</div>
      ${ui.hooks.eventExtras?.(e) || ''}
      <details class="raw"><summary>JSON gốc (bằng chứng đầy đủ)</summary><pre>${esc(JSON.stringify(e, null, 2))}</pre></details>`;
  }
  async function loadDetail(id) {
    if (!id || ui.details.has(id) || ui.loadingDetails.has(id)) return;
    ui.loadingDetails.add(id);
    try {
      const response = await fetch(`/api/event?id=${encodeURIComponent(id)}`);
      if (response.ok) ui.details.set(id, await response.json());
    } finally { ui.loadingDetails.delete(id); }
    if (ui.details.size > 300) ui.details.delete(ui.details.keys().next().value);
    for (const host of $$(`[data-detail="${CSS.escape(id)}"]`)) host.innerHTML = detailContent(id);
  }
  function detailContent(id) {
    const loaded = ui.details.get(id);
    if (!loaded) { loadDetail(id); return '<p class="hint">Đang tải chi tiết…</p>'; }
    return eventDetailHtml(loaded.event, loaded.spec, loaded.firing);
  }

  // ---- live evidence ------------------------------------------------------
  // dataLayer / InsiderQueue as F12's Console shows them: every push in order, newest first.
  async function refreshPushes() {
    if (ui.pushLoading || !ui.state) return;
    const version = `${ui.state.session?.id || ''}:${ui.state.eventCount}:${JSON.stringify(ui.state.delivery || {})}`;
    if (version === ui.pushVersion) return;
    ui.pushLoading = true;
    try {
      const response = await fetch('/api/pushes', { signal: AbortSignal.timeout(10000) });
      if (!response.ok) throw new Error('Chưa tải được dataLayer / InsiderQueue.');
      ui.pushes = (await response.json()).pushes; ui.pushVersion = version; ui.sig.events = null; render();
    } catch (error) { showError(error.message); }
    finally { ui.pushLoading = false; }
  }
  function renderPushes(f, emptyHtml) {
    const items = ui.pushes.filter(p => (!f.source || (f.source === 'GA4') === (p.queue_name === 'dataLayer')) && (!f.marked || !ui.marker || Date.parse(p.captured_at) >= ui.marker)
      && (!f.query || JSON.stringify(p).toLowerCase().includes(f.query)));
    const where = p => p.queue_name === 'InsiderDispatch' ? 'Insider.eventManager.dispatch' : p.queue_name === 'insider_object' ? 'window.insider_object' : `${p.queue_name}${Number.isInteger(p.queue_index) ? `[${p.queue_index}]` : ''}`;
    $('push-list').innerHTML = items.length ? `<div class="activity-caption">${items.length} push · giống khi gõ <code>dataLayer</code> / <code>InsiderQueue</code> trong F12 Console (mới nhất ở trên, gồm cả event hệ thống). Cột “Gửi lên server” cho biết push có thật sự được gửi lên Google / Insider hay không.</div><div class="table-scroll"><table class="checks activity-table"><thead><tr><th>Thời gian</th><th>Vị trí</th><th>Event</th><th>Gửi lên server</th><th>Nội dung push</th></tr></thead><tbody>${items.map(p => `<tr${p.event_kind !== 'business' ? ' class="muted-row"' : ''}><td>${esc(new Date(p.captured_at).toLocaleTimeString('vi-VN', { hour12: false }))}${p.historical ? '<br><small class="hint">Trước khi thu thập</small>' : ''}</td><td><code>${esc(where(p))}</code></td><td><b>${esc(p.event_name)}</b>${p.event_kind !== 'business' ? '<br><small class="hint">hệ thống</small>' : ''}</td><td>${p.event_kind === 'business' ? deliveryPill(p.delivery, p.queue_name === 'dataLayer' ? 'GA4' : 'INSIDER') : '<small class="hint">không gửi riêng</small>'}</td><td><details class="parameter-tree"><summary>${esc(short(JSON.stringify(p.payload), 90))}</summary><pre>${esc(JSON.stringify(p.payload, null, 2))}</pre></details></td></tr>`).join('')}</tbody></table></div>` : emptyHtml;
  }
  async function refreshActivity(more = false) {
    if (ui.activityLoading || !ui.state) return;
    const session = ui.state.session?.id || null;
    if (ui.activitySession !== session) {
      ui.activity = []; ui.activityNext = null; ui.activityVersion = null; ui.activityExtended = false; ui.activitySession = session;
    }
    // A pending push turns not_sent without new evidence: its count is part of the version.
    const version = `${ui.state.session?.id || ''}:${ui.state.eventCount}:${ui.state.delivery?.pending ?? ''}:${ui.state.delivery?.not_sent ?? ''}:${JSON.stringify(ui.state.prices || {})}`;
    if (!more && version === ui.activityVersion) return;
    ui.activityLoading = true;
    try {
      const response = await fetch('/api/activity?compact=1' + (more && ui.activityNext ? `&before=${encodeURIComponent(ui.activityNext)}` : ''), { signal: AbortSignal.timeout(10000) });
      if (!response.ok) throw new Error('Chưa tải được danh sách event.');
      const page = await response.json();
      if (page.session_id !== (ui.state.session?.id || null)) return;
      if (more) ui.activityExtended = true;
      if (more) ui.activity = [...ui.activity, ...page.events];
      else if (ui.activityExtended) ui.activity = [...new Map([...page.events, ...ui.activity].map(e => [e.evidence_id, e])).values()];
      else ui.activity = page.events;
      ui.activityVersion = version;
      if (more || !ui.activityExtended) ui.activityNext = page.next;
      ui.activityTotal = page.total;
      ui.sig.events = null;
      render();
    } catch (error) { showError(error.message); }
    finally { ui.activityLoading = false; }
  }
  function renderActivity(f, emptyHtml) {
    const from = $('activity-from')?.value, to = $('activity-to')?.value;
    const items = ui.activity.filter(e => {
      const at = new Date(e.captured_at); const day = `${at.getFullYear()}-${String(at.getMonth() + 1).padStart(2, '0')}-${String(at.getDate()).padStart(2, '0')}`;
      // By default only what reached Google/Insider: a push no request carried is not a fired event.
      return (f.system || (e.event_kind !== 'system' && e.event_kind !== 'observation' && !SYSTEM_EVENT.test(e.event_name))) && (!f.layer || e.layer === f.layer) && (!f.source || e.source === f.source)
        && (f.unsent || !['pending', 'not_sent', 'unverified'].includes(e.delivery))
        && (!f.marked || !ui.marker || at.getTime() >= ui.marker) && (!from || day >= from) && (!to || day <= to)
        && (!f.query || JSON.stringify(e).toLowerCase().includes(f.query));
    });
    const counts = ui.state?.delivery || {};
    const note = $('ev-delivery-note');
    // A session started with "Không đọc dataLayer / InsiderQueue" sees requests only: it cannot match F12's Console.
    const requestOnly = ui.state?.session?.capture_queues === false;
    if (note) {
      note.classList.toggle('hidden', !counts.not_sent && !counts.pending && !requestOnly);
      note.innerHTML = requestOnly
        ? '<p><b>Phiên này không đọc dataLayer / InsiderQueue</b> (đã tick “Không đọc dataLayer / InsiderQueue” ở bước 1), nên chỉ thấy request gửi lên server và không so được với F12 Console. Bỏ tick rồi mở phiên mới để thấy đủ như F12.</p>'
        : `<p>${counts.not_sent ? `<b>${counts.not_sent} event website đã push vào dataLayer / InsiderQueue nhưng không có request gửi lên Google / Insider</b>, nên không được tính là đã bắn.` : ''}${counts.pending ? ` ${counts.pending} event vừa push, đang chờ GA4/Insider gửi đi.` : ''}${f.unsent ? '' : ' Tick “Hiện cả push chưa gửi lên server” để xem, hoặc mở chế độ xem “dataLayer · InsiderQueue (F12)”.'}</p>`;
    }
    $('activity-events').innerHTML = items.length ? `<div class="activity-caption">${items.length} event đang hiển thị · ${ui.activityTotal} dòng đã ghi. Mỗi dòng là một event Google / Insider đã nhận. Bấm <b>Xem chi tiết</b> để xem request gửi lên server và dữ liệu website push.</div><div class="table-scroll"><table class="checks activity-table"><thead><tr><th>Thời gian</th><th>Event / Action</th><th>Nguồn</th><th>Tham số</th><th></th></tr></thead><tbody>${items.map(e => `<tr><td>${esc(new Date(e.captured_at).toLocaleString('vi-VN', { hour12: false }))}${e.historical ? '<br><small class="hint">Trước khi thu thập</small>' : ''}</td><td><button type="button" class="ev-toggle" data-activity-id="${esc(e.evidence_id)}"><b>${esc(e.display_name)}</b></button>${e.repeat ? ` <span class="pill warn" title="Cùng hệ thống, cùng event, cùng trang">⚠ Lặp lại sau ${esc((e.repeat.after_ms / 1000).toFixed(1))} s</span>` : ''}<br><small class="hint">${esc(e.event_name)}${e.capture?.incomplete ? ' · Thu chưa đầy đủ' : ''}</small></td><td><span class="pill">${esc(SOURCE_TEXT[e.source] || e.source)}</span> ${deliveryPill(e.delivery, e.source)}${e.measurement_id ? `<br><small class="hint">${esc(e.measurement_id)}</small>` : ''}</td><td><small>${e.default_count ?? Object.keys(e.json?.default_parameters || {}).length} default · ${e.custom_count ?? Object.keys(e.json?.custom_parameters || {}).length} custom</small>${e.prices?.length ? `<br>${priceLines(e.prices)}` : ''}</td><td><button type="button" class="btn small primary" data-activity-id="${esc(e.evidence_id)}">Xem chi tiết</button></td></tr>`).join('')}</tbody></table></div>` : emptyHtml;
    $('activity-more').classList.toggle('hidden', !ui.activityNext);
  }
  async function openActivity(id) {
    const response = await fetch(`/api/event?id=${encodeURIComponent(id)}`);
    if (!response.ok) throw new Error('Không đọc được event này.');
    const detail = await response.json(); ui.activitySelected = detail;
    const a = detail.activity, e = detail.event;
    const label = key => key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    const valueHtml = value => value && typeof value === 'object'
      ? `<details class="parameter-tree"><summary>Show Details${Array.isArray(value) ? ` · ${value.length} mục` : ''}</summary><pre>${esc(JSON.stringify(value, null, 2))}</pre></details>`
      : `<span class="parameter-value">${esc(value === null ? 'null' : String(value))}</span>`;
    const parameters = group => Object.entries(group).map(([key, value]) => `<tr><td><strong>${esc(label(key))}</strong><small class="hint parameter-key">${esc(key)}</small></td><td>${valueHtml(value)}</td></tr>`).join('') || '<tr><td colspan="2" class="hint">Nguồn thực tế không có tham số trong nhóm này.</td></tr>';
    const date = new Date(a.captured_at);
    // What reached the vendor: the push, the request that sent it, and pushed fields Google did not receive.
    const d = detail.delivery || {}, vendor = vendorName(a.source), queue = a.source === 'GA4' ? 'dataLayer' : 'InsiderQueue';
    const deliveryHtml = d.status === 'sent' ? `<div class="banner info"><p><b>✓ Đã gửi lên ${vendor}</b>${d.push && d.hit ? `, ${Math.max(0, Date.parse(d.hit.captured_at) - Date.parse(d.push.captured_at))} ms sau khi website push vào ${queue}` : d.push ? '' : ' (request gửi thẳng, không thấy push tương ứng trong ' + queue + ')'}.${a.source === 'GA4' ? ' Tham số bên dưới là những gì Google nhận được.' : ''}</p>${d.not_forwarded?.length ? `<p><b>Website có push nhưng Google không nhận:</b> ${d.not_forwarded.map(path => `<code>${esc(path)}</code>`).join(', ')}. Tag GA4 trong GTM chưa gửi các trường này.</p>` : ''}</div>`
      : d.status === 'not_sent' ? `<div class="banner error"><p><b>✗ Không gửi lên ${vendor}.</b> Website đã push vào ${queue} nhưng không có request nào mang event này lên ${vendor}, nên event chưa được bắn. Kiểm tra tag/trigger trong GTM${a.source === 'INSIDER' ? ' hoặc init của Insider' : ''}.</p></div>`
      : d.status === 'pending' ? `<div class="banner warn"><p>Website vừa push; đang chờ ${vendor} gửi request (GA4 gom event rồi mới gửi).</p></div>`
      : d.status === 'unverified' ? '<div class="banner warn"><p>Push từ trước khi bắt đầu thu thập: không xác định được đã gửi lên server hay chưa.</p></div>' : '';
    const payloadOf = view => view === 'hit' ? d.hit?.payload ?? null : view === 'push' ? (a.capture?.incomplete ? { _capture: a.capture, payload: d.push?.payload } : d.push?.payload ?? null) : a.json;
    const selectedView = () => document.querySelector('[data-activity-view][aria-pressed="true"]')?.dataset.activityView ?? 'params';
    $('activity-content').innerHTML = `<header class="insider-event-title"><h2>${esc(a.display_name)}</h2><code>${esc(a.event_name)}</code></header>
      <section class="insider-event-details"><h3>Event Details</h3><div class="kv"><div><span>Platform</span><b>Web</b></div><div><span>Date</span><b>${esc(date.toLocaleString('vi-VN', { hour12: false }))}</b></div><div><span>Time (UTC)</span><b>${esc(date.toISOString().slice(11, 19))}</b></div><div><span>Nguồn bằng chứng</span><b>${esc(a.source)} · ${esc((a.layers || [a.layer]).map(layer => LAYER_TEXT[layer] || layer).join(' + '))}</b></div></div>${e.page?.url ? `<p class="hint event-page">${esc(e.page.url)}</p>` : ''}</section>
      ${deliveryHtml}
      ${detail.prices?.length ? `<section class="price-check"><h3>Giá so với API của website</h3><div class="table-scroll"><table class="params"><thead><tr><th>Trường giá</th><th>Đã gửi</th><th>Giá trong API</th><th>Kết quả</th></tr></thead><tbody>${detail.prices.map(check => `<tr><td><code>${esc(check.field)}</code></td><td><b>${esc(vnd(check.sent))}</b></td><td>${priceApiHtml(check)}</td><td>${pricePill(check)}</td></tr>`).join('')}</tbody></table></div></section>` : ''}
      ${a.capture?.incomplete ? '<div class="banner warn">Payload thu chưa đầy đủ; không dùng bản này để kết luận PASS/FAIL của website.</div>' : ''}
      <div class="toolbar activity-actions"><button type="button" class="btn primary" id="activity-copy">Sao chép JSON</button><button type="button" class="btn" id="activity-download">Tải JSON</button></div>${ui.hooks.eventExtras?.(e) || ''}<div class="segmented"><button type="button" data-activity-view="params" aria-pressed="true">Event Details</button><button type="button" data-activity-view="json" aria-pressed="false">JSON tham số</button><button type="button" data-activity-view="hit" aria-pressed="false">Request gửi lên server</button><button type="button" data-activity-view="push" aria-pressed="false">Website push</button></div>
      <section data-activity-panel="params"><h3>Default Parameters</h3><table class="params insider-parameters"><tbody>${parameters(a.json.default_parameters)}</tbody></table><h3>Custom Parameters</h3><table class="params insider-parameters"><tbody>${parameters(a.json.custom_parameters)}</tbody></table></section>
      <section data-activity-panel="json" class="hidden"><pre class="activity-json" tabindex="0">${esc(JSON.stringify(a.json, null, 2))}</pre></section>
      <section data-activity-panel="hit" class="hidden">${d.hit ? `<p class="hint">Request thật gửi lên ${vendor} (${esc(d.hit.network?.url || '')}), đã giải mã và che dữ liệu nhạy cảm. Bằng chứng ${esc(d.hit.evidence_id)}.</p><pre class="activity-json" tabindex="0">${esc(JSON.stringify(d.hit.payload, null, 2))}</pre>` : `<p class="hint">Không có request nào gửi event này lên ${vendor}.</p>`}</section>
      <section data-activity-panel="push" class="hidden">${d.push ? `<p class="hint">Dữ liệu website push vào ${queue}${d.push.queue_name && d.push.queue_name !== queue ? ` (${esc(d.push.queue_name)})` : ''}. Bằng chứng ${esc(d.push.evidence_id)}.</p><pre class="activity-json" tabindex="0">${esc(JSON.stringify(d.push.payload, null, 2))}</pre>` : `<p class="hint">Không thấy push tương ứng trong ${queue}: request được gửi thẳng (ví dụ event GA4 tự động hoặc trigger trong GTM).</p>`}</section>
      <p class="hint">Chỉ hiển thị tham số đã thu; không điền thêm từ mẫu Excel. Hai nguồn bằng chứng không tự chứng minh website phát hai lần.</p>`;
    $('activity-copy').onclick = run(async () => {
      const value = payloadOf(selectedView());
      try { await navigator.clipboard.writeText(JSON.stringify(value, null, 2)); toast('Đã sao chép toàn bộ JSON.', 'ok'); }
      catch { throw new Error('Trình duyệt chưa cho phép sao chép. Dùng nút Tải JSON để lấy đầy đủ dữ liệu.'); }
    });
    $('activity-download').onclick = () => {
      const view = selectedView(), value = payloadOf(view);
      const blob = new Blob([JSON.stringify(value, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = `${e.evidence_id}${['hit', 'push'].includes(view) ? `-${view}` : ''}.json`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    };
    $('activity-dialog').showModal();
  }
  // SDK setup and GTM lifecycle pushes; hidden unless asked for, they are not user actions.
  const SYSTEM_EVENT = /^(?:gtm\.|gtag\.|insider_|ecommerce_reset$|QUEUE_ITEM$)/;
  const isSystem = e => e.layer === 'JS_QUEUE' && SYSTEM_EVENT.test(e.event_name);
  function eventFilters() {
    return { layer: $('ev-layer')?.value || '', source: $('ev-source')?.value || '', query: ($('ev-search')?.value || '').trim().toLowerCase(),
      marked: !!$('ev-marked')?.checked, system: !!$('ev-system')?.checked, unsent: !!$('ev-unsent')?.checked, group: ui.groupFilter };
  }
  function renderSourceFilter(s) {
    const select = $('ev-source'); if (!select) return;
    const sources = [...new Set((s.eventSummary || []).map(g => g.source))].sort();
    const sig = sources.join('|'); if (sig === ui.sig.sources) return; ui.sig.sources = sig;
    const current = select.value;
    select.innerHTML = '<option value="">Mọi nguồn</option>' + sources.map(src => `<option value="${esc(src)}">${esc(src)}</option>`).join('');
    select.value = sources.includes(current) ? current : '';
  }
  function renderFilterBar(f) {
    const bar = $('ev-filterbar'); if (!bar) return;
    const parts = [];
    if (f.group) parts.push(`<b>${esc(f.group.name)}</b> · ${esc(LAYER_TEXT[f.group.layer] || f.group.layer)} · ${esc(f.group.source)}`);
    else {
      if (f.layer) parts.push(esc(LAYER_TEXT[f.layer] || f.layer));
      if (f.source) parts.push(esc(f.source));
      if (f.query) parts.push(`“${esc(f.query)}”`);
    }
    if (f.marked && ui.marker) parts.push(`sau mốc ${esc(clock(new Date(ui.marker).toISOString()))}`);
    const active = parts.length > 0;
    bar.classList.toggle('hidden', !active && ui.view === 'groups');
    bar.innerHTML = `${ui.view === 'stream' ? '<button type="button" class="btn small" data-action="events-back">← Về danh sách event</button>' : ''}
      <span>${active ? `Đang xem: ${parts.join(' · ')}` : 'Tất cả event'}</span>
      ${active ? '<button type="button" class="btn ghost small" data-action="events-clear">✕ Bỏ lọc</button>' : ''}`;
  }
  function renderEvents(s) {
    const layer = $('ev-layer'), rawView = ui.view === 'groups' || ui.view === 'stream';
    if (layer) { layer.classList.toggle('hidden', !rawView); if (!rawView) layer.value = ''; }
    if (ui.view === 'activity') void refreshActivity();
    if (ui.view === 'f12') void refreshPushes();
    renderSourceFilter(s);
    const f = eventFilters();
    if ($('ev-search')) $('ev-search').placeholder = ui.view === 'activity' ? 'Tìm tên event, nguồn hoặc evidence ID…' : 'Tìm event, giá trị, evidence ID…';
    const view = JSON.stringify([f, ui.view, ui.marker, ui.expandedGroup, $('activity-from')?.value, $('activity-to')?.value, ui.activity.length, ui.pushVersion]);
    const sig = JSON.stringify([s.eventCount, s.events.at(-1)?.evidence_id, view, s.cases.length, s.delivery]); if (sig === ui.sig.events) return;
    // Keep an expanded event steady while new evidence arrives; offer to refresh instead.
    const reading = ui.view === 'stream' && $$('#events details[open]').length > 0 && ui.sig.eventsView === view;
    if (reading) { const note = $('ev-pending'); if (note) { note.classList.remove('hidden'); note.textContent = 'Có event mới · bấm để cập nhật danh sách'; } return; }
    $('ev-pending')?.classList.add('hidden');
    ui.sig.events = sig; ui.sig.eventsView = view;
    setText('events-count', String((s.eventSummary || []).filter(g => f.system || !(g.layer === 'JS_QUEUE' && SYSTEM_EVENT.test(g.event_name))).length));
    for (const b of $$('[data-view]')) b.setAttribute('aria-pressed', String(b.dataset.view === ui.view));
    renderFilterBar(f);
    $('event-groups')?.classList.toggle('hidden', ui.view !== 'groups');
    $('events')?.classList.toggle('hidden', ui.view !== 'stream');
    $('activity-events')?.classList.toggle('hidden', ui.view !== 'activity');
    $('push-list')?.classList.toggle('hidden', ui.view !== 'f12');
    $('activity-filters')?.classList.toggle('hidden', ui.view !== 'activity');
    if (ui.view !== 'activity') $('activity-more')?.classList.add('hidden');
    const emptyHtml = !s.session
      ? '<div class="empty"><span class="empty-art"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="3"/><path d="M3 9h18m-13 6 3-3 3 5 3-3"/></svg></span><strong>Sẵn sàng cho phiên kiểm tra đầu tiên?</strong><p>Nhập website cần kiểm tra, mở trình duyệt test và thực hiện thao tác. Event thực tế sẽ xuất hiện tại đây.</p><div class="empty-actions"><button type="button" class="btn primary" data-setup-stage="session">Thiết lập website →</button><button type="button" class="btn" data-action="use-demo">Thử với demo</button></div><div class="empty-steps"><span><b>1</b>Mở website</span><span><b>2</b>Thực hiện thao tác</span><span><b>3</b>Xem event &amp; đối chiếu</span></div></div>'
      : s.eventCount ? '<div class="empty"><strong>Không có event khớp bộ lọc</strong>Bấm “Bỏ lọc”, bỏ tick “Chỉ sau mốc” hoặc tick “Hiện event hệ thống”.</div>'
      : '<div class="empty"><strong>Chưa nhận được event</strong>Thao tác trên trình duyệt test. Không thấy request? Xem tab <b>Endpoint</b> để thêm endpoint tracking của website.</div>';
    if (ui.view === 'activity') {
      renderActivity(f, emptyHtml);
    } else if (ui.view === 'f12') {
      renderPushes(f, emptyHtml);
    } else if (ui.view === 'groups') {
      const markerSince = ui.marker && f.marked;
      // Counts after a marker come from the buffered recent events; totals come from the server summary.
      const recentCounts = new Map();
      if (markerSince) for (const e of s.events) if (afterMarker(e) && (!e.network?.phase || e.network.phase === 'request')) { const key = [e.layer, e.source, e.event_name].join('|'); recentCounts.set(key, (recentCounts.get(key) || 0) + 1); }
      const groups = (s.eventSummary || []).filter(g => (f.system || !(g.layer === 'JS_QUEUE' && SYSTEM_EVENT.test(g.event_name))) && (!f.layer || g.layer === f.layer) && (!f.source || g.source === f.source) && (!f.query || `${g.event_name} ${g.source} ${g.pages.join(' ')}`.toLowerCase().includes(f.query)) && (!markerSince || recentCounts.has(g.key)));
      $('event-groups').innerHTML = groups.length ? `<div class="table-scroll"><table class="checks groups"><thead><tr><th>Event</th><th>Tầng · nguồn</th><th>${markerSince ? 'Sau mốc / tổng' : 'Số lần'}</th><th>Lần cuối · trang</th><th></th></tr></thead><tbody>${groups.map(g => `<tr>
        <td><button type="button" class="ev-toggle" data-expand="${esc(g.key)}" aria-expanded="${ui.expandedGroup === g.key}">${ui.expandedGroup === g.key ? '▾' : '▸'} <b>${esc(g.event_name)}</b></button>${g.failed ? ` <span class="pill FAIL">${g.failed} lỗi</span>` : ''}${g.not_sent ? ` <span class="pill FAIL">${g.not_sent} không gửi lên server</span>` : ''}</td>
        <td><span class="pill layer">${esc(LAYER_TEXT[g.layer] || g.layer)}</span> <span class="pill">${esc(g.source)}</span></td>
        <td><b>${markerSince ? `${recentCounts.get(g.key)} / ` : ''}${g.count}</b>${g.bound ? `<br><small class="hint">${g.bound} trong bước</small>` : ''}</td>
        <td><small>${esc(clock(g.last_at))}</small><br><small class="hint">${esc(short(g.pages.join(', '), 60))}</small></td>
        <td class="row-actions"><button type="button" class="btn small" data-group-view="${esc(g.key)}">Tất cả ${g.count} lần</button> <button type="button" class="btn small primary" data-build="${esc(g.last_evidence_id)}">Tạo rule</button></td></tr>
        ${ui.expandedGroup === g.key ? `<tr class="detail-row"><td colspan="5"><div class="ev-detail" data-detail="${esc(g.last_evidence_id)}">${detailContent(g.last_evidence_id)}</div></td></tr>` : ''}`).join('')}</tbody></table></div>` : emptyHtml;
    } else {
      const list = s.events.slice().reverse().filter(e => (f.system || f.group || !isSystem(e))
        && (!f.group || (e.layer === f.group.layer && e.source === f.group.source && e.event_name === f.group.name))
        && (f.group || ((!f.layer || e.layer === f.layer) && (!f.source || e.source === f.source)))
        && (!f.marked || afterMarker(e)) && (!f.query || JSON.stringify(e).toLowerCase().includes(f.query)));
      // Identical consecutive pushes (a site re-firing, or repeated clicks) collapse into one row.
      const rows = [];
      for (const e of list) {
        const key = JSON.stringify([e.layer, e.source, e.event_name, e.network?.phase, e.payload]);
        const last = rows.at(-1);
        if (last && last.key === key) { last.count++; last.oldest = e; } else rows.push({ key, event: e, count: 1, oldest: e });
      }
      const firstRender = ui.seenEvents.size === 0;
      $('events').innerHTML = rows.map(({ event: e, count, oldest }) => {
        const fresh = !firstRender && !ui.seenEvents.has(e.evidence_id);
        const phase = e.network?.phase ? `${e.network.method || ''} ${e.network.phase}${e.network.status ? ` ${e.network.status}` : ''}${e.network.error ? ` ${e.network.error}` : ''}` : e.queue_name || '';
        return `<details class="event${fresh ? ' flash' : ''}" data-ev="${esc(e.evidence_id)}" ${ui.openEvents.has(e.evidence_id) ? 'open' : ''}><summary>
          <time>${esc(clock(e.captured_at))}</time><span class="ev-name">${esc(e.event_name)}</span>${count > 1 ? `<span class="pill warn" title="Từ ${esc(clock(oldest.captured_at))}">×${count} giống hệt nhau</span>` : ''}<span class="pill layer">${esc(LAYER_TEXT[e.layer] || e.layer)}</span><span class="pill">${esc(e.source)}</span>
          <span class="ev-meta">${esc(phase)} · ${e.step_id ? esc(e.test_case_id) : 'chưa gắn bước'}</span></summary>
          ${count > 1 ? `<p class="hint" style="margin:0 0 8px">Bắn ${count} lần với payload giống hệt nhau từ ${esc(clock(oldest.captured_at))} đến ${esc(clock(e.captured_at))}: website phát lặp, hoặc thao tác được bấm nhiều lần.</p>` : ''}
          <div class="ev-detail" data-detail="${esc(e.evidence_id)}">${ui.openEvents.has(e.evidence_id) ? detailContent(e.evidence_id) : ''}</div></details>`;
      }).join('') || emptyHtml;
      for (const e of s.events) ui.seenEvents.add(e.evidence_id);
    }
  }
  function showGroup(key) {
    const [layer, source, ...name] = key.split('|');
    ui.groupFilter = { layer, source, name: name.join('|') }; ui.view = 'stream';
    ui.sig.events = null; if (ui.state?.eventsCompact) void refresh(); else render();
  }
  function clearEventFilters() {
    ui.groupFilter = null;
    for (const id of ['ev-layer', 'ev-source', 'ev-search']) if ($(id)) $(id).value = '';
    if ($('ev-marked')) $('ev-marked').checked = false;
    ui.sig.events = null; render();
  }
  async function jumpToEvidence(id) {
    selectTab('events'); ui.view = 'stream'; ui.groupFilter = null;
    for (const [elId, value] of [['ev-layer', ''], ['ev-source', '']]) if ($(elId)) $(elId).value = value;
    if ($('ev-marked')) $('ev-marked').checked = false;
    if ($('ev-search')) $('ev-search').value = id; ui.openEvents.add(id); ui.sig.events = null;
    if (ui.state?.eventsCompact) await refresh(); else render();
    const target = document.querySelector(`[data-ev="${CSS.escape(id)}"]`);
    if (target) target.scrollIntoView({ block: 'center', behavior: 'smooth' });
    else if (id.startsWith('STEP-')) toast('Đây là bằng chứng của bước (event vắng mặt). Xem steps.jsonl trong thư mục phiên.');
    else toast('Event không nằm trong 100 bằng chứng gần nhất; xem events.jsonl trong thư mục phiên.');
  }

  // ---- specification coverage ------------------------------------------------
  function renderFlowChoices() {
    const query = $('comparison-flow-search').value.trim().toLowerCase();
    const flows = (ui.state?.specCoverage?.selection.flows || []).filter(flow => flow.name.toLowerCase().includes(query));
    $('comparison-flow-list').innerHTML = flows.map(flow => `<button type="button" class="flow-choice" data-choose-flow="${esc(flow.name)}"><strong>${esc(flow.name)}</strong><span>${flow.case_ids.length} event đặc tả · ${esc(flow.sources.join(', '))}</span><b>Kiểm tra luồng này →</b></button>`).join('') || '<p class="empty">Không tìm thấy luồng phù hợp.</p>';
  }
  function openFlowPicker() {
    selectTab('spec');
    if (!ui.state?.running) throw new Error('Mở website để bắt đầu phiên trước khi chọn luồng.');
    if (!ui.state.cases.length) { revealSetup('spec'); throw new Error('Nhập file đặc tả trước khi chọn luồng.'); }
    $('comparison-flow-search').value = ''; renderFlowChoices(); $('comparison-flow-dialog').showModal(); $('comparison-flow-search').focus();
  }
  let eventChoices = null;
  let previewSequence = 0;
  function renderEventChoices() {
    const query = $('comparison-event-search').value.trim().toLowerCase();
    const events = (eventChoices?.events || []).filter(event => `${event.event_name} ${event.page?.url || ''} ${event.evidence_id}`.toLowerCase().includes(query));
    if (!$('comparison-candidates')) $('comparison-event-list').innerHTML = '<div class="comparison-picker"><aside id="comparison-candidates" aria-label="Event trong lượt hiện tại"></aside><section id="comparison-preview" aria-live="polite"></section></div>';
    const selected = events.find(event => event.evidence_id === eventChoices.previewId) || events[0];
    $('comparison-candidates').innerHTML = `<button type="button" class="btn" data-choose-comparison-event="auto">Ghép tự động</button>` + events.map(event => `<button type="button" class="comparison-candidate" data-preview-comparison="${esc(event.evidence_id)}" aria-pressed="${selected?.evidence_id === event.evidence_id}"><strong>${esc(event.event_name)}</strong><span>${esc(clock(event.captured_at))} · ${esc(event.source)} · ${esc(LAYER_TEXT[event.layer] || event.layer)}</span><small>${esc(event.page?.url || '')}</small></button>`).join('');
    if (selected) void previewComparison(selected.evidence_id);
    else { previewSequence++; $('comparison-preview').innerHTML = '<div class="empty"><strong>Chưa có event phù hợp</strong>Thao tác trên website rồi mở lại danh sách.</div>'; }
  }
  async function previewComparison(id) {
    const seq = ++previewSequence, choices = eventChoices, host = $('comparison-preview');
    choices.previewId = id;
    for (const button of $$('[data-preview-comparison]')) button.setAttribute('aria-pressed', String(button.dataset.previewComparison === id));
    host.innerHTML = '<p role="status">Đang mở so sánh…</p>';
    try {
      let detail = choices.cache.get(id);
      if (!detail) {
        const response = await fetch(`/api/event?id=${encodeURIComponent(id)}&case_id=${encodeURIComponent(choices.case_id)}`);
        if (!response.ok) throw new Error('Không tải được event. Bấm chọn lại để thử lại.');
        detail = await response.json(); choices.cache.set(id, detail);
      }
      if (seq !== previewSequence || eventChoices !== choices || !host.isConnected || !$('comparison-event-dialog').open) return;
      const model = window.EventQAComparison.build(caseById(choices.case_id), detail);
      host.innerHTML = `<div class="comparison-preview-title"><div><strong>${esc(detail.event.event_name)}</strong><small>${esc(clock(detail.event.captured_at))} · ${esc(detail.event.evidence_id)}</small></div><button type="button" class="btn primary" data-choose-comparison-event="${esc(id)}">Dùng event này</button></div>${window.EventQAComparison.render(model, { owner: 'preview' })}`;
    } catch (error) { if (seq === previewSequence && host.isConnected) host.innerHTML = `<p role="alert">${esc(error.message)}</p>`; }
  }
  async function openEventPicker(caseId) {
    const response = await fetch(`/api/comparison/candidates?case_id=${encodeURIComponent(caseId)}`), data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Không đọc được event của lượt này.');
    const row = ui.state.specCoverage?.rows.find(row => row.case_id === caseId);
    previewSequence++; eventChoices = { ...data, case_id: caseId, previewId: row?.last_fail_evidence_id || row?.last_evidence_id, cache: new Map() }; $('comparison-event-search').value = '';
    $('comparison-event-hint').textContent = `${caseById(caseId)?.source} · ${caseById(caseId)?.rules[0]?.event_name} · Luồng ${data.attempt.flow}. Chọn event để xem thử, rồi bấm “Dùng event này”.`;
    $('comparison-event-list').innerHTML = ''; $('comparison-event-dialog').showModal(); renderEventChoices();
  }
  function renderComparisonControls(s) {
    const host = $('comparison-controls'); if (!host) return;
    const selection = s.specCoverage?.selection, attempt = selection?.attempt;
    const sig = JSON.stringify([selection, s.running, !!s.currentStep, !!ui.busy, s.cases.length]); if (host.dataset.sig === sig) return; host.dataset.sig = sig;
    const disabled = !s.running || s.currentStep || ui.busy ? 'disabled' : '';
    host.innerHTML = `<div><span class="eyebrow">ĐỐI CHIẾU THEO LUỒNG</span><h2>${attempt ? esc(attempt.flow) : 'Bạn muốn kiểm tra luồng nào?'}</h2><p>${attempt ? `${selection.active ? 'Đang nhận event mới' : 'Đã dừng nhận event cho lượt này'} · Bắt đầu ${esc(clock(attempt.started_at))} · Lượt ${selection.attempts.filter(item => item.flow === attempt.flow).length}` : 'Nhập đặc tả để xem các luồng. Chỉ bắt đầu so sánh sau khi bạn chọn luồng cần kiểm tra.'}</p></div><div class="comparison-actions"><button type="button" class="btn primary" data-action="select-flow" ${disabled || (!s.cases.length ? 'disabled' : '')}>${attempt ? 'Đổi luồng' : 'Chọn luồng kiểm tra'}</button>${attempt ? `<button type="button" class="btn" data-action="retest-flow" ${disabled}>Test lại</button>${selection.active ? `<button type="button" class="btn" data-action="pause-comparison" ${disabled}>Tạm dừng đối chiếu</button>` : ''}` : ''}</div>`;
  }
  const valueAt = (value, path) => {
    const parts = path.split('.'); let current = value;
    for (let i = 0; i < parts.length; i++) {
      if (current === null || typeof current !== 'object') return undefined;
      const rest = parts.slice(i).join('.');
      if (Object.hasOwn(current, rest)) return current[rest];
      current = current[parts[i]];
    }
    return current;
  };
  let detailSequence = 0;
  async function openSpecDetail(id) {
    const c = caseById(id); if (!c) return;
    const seq = ++detailSequence, dialog = $('spec-detail-dialog');
    $('spec-detail-content').innerHTML = '<p role="status">Đang mở so sánh…</p>';
    if (!dialog.open) dialog.showModal();
    const row = ui.state.specCoverage?.rows.find(r => r.case_id === id);
    const evidence = row?.last_fail_evidence_id || row?.last_evidence_id;
    try {
      const response = evidence ? await fetch(`/api/event?id=${encodeURIComponent(evidence)}&case_id=${encodeURIComponent(id)}`) : null;
      if (response && !response.ok) throw new Error('Không tải được event. Bấm Thử lại để mở lại.');
      const loaded = response ? await response.json() : null;
      if (seq !== detailSequence || !dialog.open) return;
      const model = window.EventQAComparison.build(c, loaded, row);
      $('spec-detail-content').innerHTML = `<div class="event-comparison-title"><div><span class="eyebrow">${esc(c.source)} · ${esc(c.flow)}</span><h2>${esc(c.rules[0]?.event_name || c.name)}</h2><small>${esc(whereSpec(c.provenance?.sheet, c.provenance?.row))}${evidence ? ` · ${esc(clock(loaded.event.captured_at))}` : ''}</small></div>${row?.attempt_id && !row.attempt_id.startsWith('step:') ? `<button type="button" class="btn" data-change-comparison-event="${esc(id)}">Đổi event so sánh</button>` : ''}</div>${window.EventQAComparison.render(model)}
        <details class="comparison-extra"><summary>Ghi chú và dữ liệu gốc</summary><p>${esc(c.description)}</p><p>${esc(c.notes)}</p><div class="contract-columns"><section><h3>Đặc tả gốc</h3><pre>${esc(c.sample_text || JSON.stringify(c.sample || {}, null, 2))}</pre><h3>Cách kiểm tra (nâng cao)</h3><pre>${esc(JSON.stringify(c.rules, null, 2))}</pre></section><section><h3>Event gốc · ${esc(loaded?.event.source || c.source)}</h3><pre>${esc(loaded ? JSON.stringify(loaded.event.payload, null, 2) : 'Chưa có event')}</pre>${loaded?.delivery?.push && loaded.delivery.push.evidence_id !== loaded.event.evidence_id ? `<h3>Dữ liệu trên website · ${esc(loaded.delivery.push.source)}</h3><pre>${esc(JSON.stringify(loaded.delivery.push.payload, null, 2))}</pre>` : ''}${loaded?.delivery?.hit ? `<h3>Dữ liệu đã gửi · ${esc(loaded.delivery.hit.source)}</h3><pre>${esc(JSON.stringify(loaded.delivery.hit.payload, null, 2))}</pre>` : ''}</section></div></details>`;
    } catch (error) { if (seq === detailSequence && dialog.open) $('spec-detail-content').innerHTML = `<p role="alert">${esc(error.message)}</p><button type="button" class="btn" data-spec-detail="${esc(id)}">Thử lại</button>`; }
  }
  const SPEC_STATUS = { NOT_SELECTED: ['', 'Chưa chọn luồng'], MATCH: ['PASS', 'Chưa thấy lỗi'], MISMATCH: ['FAIL', 'Có lỗi'], REVIEW: ['REVIEW', 'Cần kiểm tra thêm'], NOT_SEEN: ['', 'Chưa thấy trong lượt này'], NOT_SENT: ['FAIL', 'Chưa thấy gửi đi'], PENDING: ['REVIEW', 'Đang chờ gửi'] };
  function renderSpec(s) {
    const host = $('spec-table'); if (!host) return;
    const cov = s.specCoverage;
    renderComparisonControls(s);
    $('spec-format-note')?.classList.toggle('hidden', !s.cases.some(c => c.payload_format === 'default_custom_parameters'));
    const f = { flow: $('spec-flow')?.value || '', platform: $('spec-platform')?.value || '', status: $('spec-status')?.value || '', query: ($('spec-search')?.value || '').trim().toLowerCase() };
    const sig = JSON.stringify([cov?.selection, cov?.totals, cov?.rows.map(r => [r.case_id, r.seen, r.status, r.issues.length, r.last_evidence_id, r.manual]), cov?.unmatched.length, f]); if (sig === ui.sig.spec) return; ui.sig.spec = sig;
    setText('spec-count', cov ? `${cov.totals.seen}/${cov.totals.rows}` : '0');
    if (!cov) { $('spec-totals').innerHTML = ''; host.innerHTML = '<div class="empty"><strong>Chưa có đặc tả</strong>Nhập file Excel hoặc JSON trong phần Đặc tả, sau đó chọn luồng cần kiểm tra.</div>'; return; }
    const t = cov.totals;
    $('spec-totals').innerHTML = [['Cần kiểm tra', t.rows], ['Đã gửi', t.seen], ['Chưa thấy lỗi', t.match], ['Có lỗi', t.mismatch], ['Chưa thấy gửi đi', t.not_sent ?? 0], ['Chưa có event', t.not_seen], ['Không có trong đặc tả', t.unmatched]].map(([k, v]) => `<div><span>${k}</span><b>${v}</b></div>`).join('');
    const flows = [...new Set(cov.rows.map(r => r.flow).filter(Boolean))];
    const select = $('spec-flow'); const flowSig = flows.join('|');
    if (select.dataset.sig !== flowSig) { const current = select.value; select.innerHTML = '<option value="">Mọi luồng</option>' + flows.map(fl => `<option>${esc(fl)}</option>`).join(''); select.value = flows.includes(current) ? current : ''; select.dataset.sig = flowSig; }
    const text = r => `${r.event_name} ${r.notes} ${r.description} ${r.flow}`.toLowerCase();
    const rows = f.status === 'UNMATCHED' ? [] : cov.rows.filter(r => (!f.flow || r.flow === f.flow) && (!f.platform || r.source === f.platform) && (!f.query || text(r).includes(f.query))
      && (!f.status || (f.status === 'FIRED' ? r.seen > 0 : r.status === f.status)))
      // Rows with evidence first (mismatches and pushes never sent on top), then the rest in specification order.
      .sort((a, b) => (b.seen > 0 || b.not_sent > 0) - (a.seen > 0 || a.not_sent > 0) || ['MISMATCH', 'NOT_SENT'].includes(b.status) - ['MISMATCH', 'NOT_SENT'].includes(a.status) || 0);
    const unmatched = (!f.status || f.status === 'UNMATCHED') && !f.flow ? cov.unmatched.filter(u => (!f.platform || u.source === f.platform) && (!f.query || u.event_name.toLowerCase().includes(f.query))) : [];
    host.innerHTML = (rows.length || unmatched.length) ? `<div class="table-scroll"><table class="checks spec-overview"><thead><tr><th>STT</th><th>Event</th><th>Nền tảng</th><th>Kết quả</th><th>Số lần</th><th>So sánh</th></tr></thead><tbody>
      ${rows.map(r => { const [cls, label] = SPEC_STATUS[r.status] || ['', r.status]; return `<tr><td>${esc(r.stt || r.row || '')}</td>
        <td><button type="button" class="spec-event-name" data-spec-detail="${esc(r.case_id)}">${esc(r.event_name)}</button><small class="spec-event-location">${esc(r.flow)} · ${esc(whereSpec(r.sheet, r.row))}</small></td>
        <td><span class="pill">${esc(r.source)}</span></td><td><span class="pill ${esc(cls)}">${esc(label)}</span>${r.manual ? '<small class="spec-event-location">Event bạn chọn</small>' : ''}</td><td>${esc(r.seen || 0)}</td>
        <td><button type="button" class="btn" data-spec-detail="${esc(r.case_id)}">Xem so sánh</button></td></tr>`; }).join('')}
      ${unmatched.map(u => `<tr><td>—</td><td>${esc(u.event_name)}</td><td><span class="pill">${esc(u.source)}</span></td><td><span class="pill warn">Ngoài đặc tả</span></td><td>${u.count}</td><td><button type="button" class="btn" data-evidence="${esc(u.last_evidence_id)}">Xem event</button></td></tr>`).join('')}
      </tbody></table></div>` : '<div class="empty"><strong>Không có dòng khớp bộ lọc</strong></div>';
  }

  // ---- firing checks ----------------------------------------------------------
  function renderFiring(s) {
    const host = $('firing-table'); if (!host || !s.firing) return;
    const status = $('firing-status')?.value || '';
    const sig = JSON.stringify([s.firing.summary, s.firing.problemCount, status]); if (sig === ui.sig.firing) return; ui.sig.firing = sig;
    const fails = s.firing.summary.reduce((n, r) => n + r.fail, 0), warns = s.firing.summary.reduce((n, r) => n + r.warn, 0);
    setText('firing-count', String(fails + warns));
    $('firing-summary').innerHTML = `<table class="params"><thead><tr><th>Quy tắc</th><th>Đạt</th><th>Cảnh báo</th><th>Lỗi</th></tr></thead><tbody>${s.firing.summary.map(r => `<tr><td>${esc(r.label)}</td><td>${r.pass ? `<span class="pill PASS">${r.pass}</span>` : '—'}</td><td>${r.warn ? `<span class="pill REVIEW">${r.warn}</span>` : '—'}</td><td>${r.fail ? `<span class="pill FAIL">${r.fail}</span>` : '—'}</td></tr>`).join('')}</tbody></table>`;
    const problems = s.firing.problems.filter(p => !status || p.status === status);
    host.innerHTML = problems.length ? `<div class="table-scroll"><table class="checks"><thead><tr><th>Giờ</th><th>Event</th><th>Quy tắc</th><th>Chi tiết</th></tr></thead><tbody>${problems.map(p => { const [cls, icon] = FIRING_STATUS[p.status]; return `<tr><td><small>${esc(clock(p.at))}</small></td><td><b>${esc(p.event_name)}</b><br><small class="hint">${esc(p.source)} · ${esc(LAYER_TEXT[p.layer] || p.layer)}</small></td><td><span class="pill ${cls}">${icon} ${esc(RULE_TEXT[p.rule] || p.rule)}</span></td><td>${esc(p.message)}<br><button type="button" class="evlink" data-evidence="${esc(p.id)}">Xem event</button></td></tr>`; }).join('')}</tbody></table></div>${s.firing.problemCount > s.firing.problems.length ? `<p class="hint">Hiện 200 vấn đề gần nhất / ${s.firing.problemCount}. Đầy đủ trong sheet Firing Checks của báo cáo.</p>` : ''}`
      : `<div class="empty"><strong>${s.eventCount ? 'Không có vấn đề về cách bắn' : 'Chưa có event'}</strong>${s.eventCount ? 'Mọi event đã thu đều đạt các quy tắc.' : 'Thao tác trên website để thu event.'}</div>`;
  }

  // ---- prices against the website's API ------------------------------------
  const PRICE_STATUS = { MISMATCH: ['FAIL', 'Lệch API'], NO_API: ['', 'Không thấy trong API'], MATCH_PAGE: ['PASS', 'Khớp giá trên API'], MATCH: ['PASS', 'Khớp API'] };
  const vnd = value => typeof value === 'number' ? value.toLocaleString('vi-VN') : '—';
  const apiWhere = url => { try { const parsed = new URL(url); return parsed.host + parsed.pathname; } catch { return url || ''; } };
  const PRICE_MARK = { MATCH: ['PASS', '✓ khớp'], MATCH_PAGE: ['PASS', '✓ khớp'], MISMATCH: ['FAIL', '✗ lệch'], NO_API: ['', 'chưa thấy trong API'] };
  // Under an event in the list: the price sent and the price the API gave, the ones that differ first.
  const priceLines = list => [...list].sort((a, b) => (b.status === 'MISMATCH') - (a.status === 'MISMATCH')).slice(0, 2)
    .map(p => `<small class="price-line"><code>${esc(p.field)}</code> gửi ${esc(vnd(p.sent))} · API ${p.api != null ? `<b>${esc(vnd(p.api))}</b>${p.times ? ` × ${p.times}` : ''}` : '—'} <span class="pill ${PRICE_MARK[p.status][0]}">${esc(PRICE_MARK[p.status][1])}</span></small>`).join('<br>')
    + (list.length > 2 ? `<br><small class="hint">+${list.length - 2} giá khác · tab Giá vs API</small>` : '');
  const pricePill = check => `<span class="pill ${PRICE_STATUS[check.status][0]}">${esc(PRICE_STATUS[check.status][1])}</span>${check.stale ? `<br><small class="hint">Khớp API cũ lúc ${esc(clock(check.stale.at))}: giá chưa cập nhật</small>` : ''}${check.status === 'MATCH_PAGE' ? '<br><small class="hint">Không xác định được sản phẩm trong API</small>' : ''}`;
  const priceApiHtml = check => check.api
    ? `<b>${esc(vnd(check.api.value))}</b>${check.api.times ? ` × ${check.api.times} (số lượng)` : ''}<br><small class="hint"><code>${esc(check.api.path)}</code><br>${esc(apiWhere(check.api.url))} · ${esc(clock(check.api.at))}</small>${check.status === 'MISMATCH' && check.candidates?.length > 1 ? `<br><small class="hint">Giá khác của sản phẩm trong API: ${check.candidates.slice(1).map(other => `${esc(vnd(other.value))} (<code>${esc(other.path.replace(/^.*[.]/, ''))}</code>)`).join(', ')}</small>` : ''}`
    : check.candidates?.length ? `<small class="hint">Giá cùng loại trong API của trang: ${check.candidates.map(other => `${esc(vnd(other.value))} (<code>${esc(other.path)}</code>)`).join(', ')}</small>` : '<small class="hint">API không có giá loại này</small>';
  async function refreshPrices() {
    if (ui.priceLoading || !ui.state) return;
    const version = `${ui.state.session?.id || ''}:${JSON.stringify(ui.state.prices || {})}`;
    if (version === ui.priceVersion) return;
    ui.priceLoading = true;
    try {
      const response = await fetch('/api/prices', { signal: AbortSignal.timeout(10000) });
      if (!response.ok) throw new Error('Chưa tải được kết quả so giá.');
      const result = await response.json();
      ui.prices = result.checks; ui.apiPrices = result.api_prices || []; ui.priceVersion = version; ui.sig.prices = null; render();
    } catch (error) { showError(error.message); }
    finally { ui.priceLoading = false; }
  }
  function renderPrices(s) {
    const summary = s.prices || {};
    setText('prices-count', String(summary.mismatch || 0));
    if (ui.tab !== 'prices') return;
    void refreshPrices();
    const host = $('prices-table'); if (!host) return;
    const status = $('prices-status')?.value || '';
    const sig = JSON.stringify([ui.priceVersion, status, s.session?.id]); if (sig === ui.sig.prices) return; ui.sig.prices = sig;
    $('prices-summary').innerHTML = summary.total ? `<div class="kv"><div><span>Giá đã kiểm</span><b>${summary.total}</b></div><div><span>Khớp API</span><b>${summary.match + summary.match_page}</b></div><div><span>Lệch API</span><b class="${summary.mismatch ? 'text-fail' : ''}">${summary.mismatch}</b></div><div><span>Không thấy trong API</span><b>${summary.no_api}</b></div><div><span>Response API đã đọc</span><b>${summary.api_responses}</b></div></div>` : '';
    const items = !status ? [...(ui.prices || [])].sort((a, b) => b.at.localeCompare(a.at))
      : (ui.prices || []).filter(check => status === 'MISMATCH' ? check.status === 'MISMATCH' : ['MISMATCH', 'NO_API'].includes(check.status));
    const off = s.session?.compare_api === false;
    host.innerHTML = items.length ? `<div class="table-scroll"><table class="checks"><thead><tr><th>Giờ</th><th>Event</th><th>Trường giá</th><th>Đã gửi</th><th>Giá trong API</th><th>Kết quả</th></tr></thead><tbody>${items.map(check => `<tr><td><small>${esc(clock(check.at))}</small></td><td><b>${esc(check.event)}</b><br><small class="hint">${esc(SOURCE_TEXT[check.source] || check.source)}${check.name ? ` · ${esc(short(check.name, 50))}` : ''}</small><br><button type="button" class="evlink" data-activity-id="${esc(check.evidence_id)}">Xem event</button></td><td><code>${esc(check.field)}</code></td><td><b>${esc(vnd(check.sent))}</b>${check.currency ? ` <small class="hint">${esc(check.currency)}</small>` : ''}</td><td>${priceApiHtml(check)}</td><td>${pricePill(check)}</td></tr>`).join('')}</tbody></table></div>`
      : `<div class="empty"><strong>${off ? 'Phiên này đã tắt So giá với API' : summary.total ? 'Không có giá lệch API' : summary.api_responses ? 'Chưa có event nào gửi giá' : 'Chưa đọc được API nào có giá'}</strong>${off ? 'Bật lại ở bước 1 → Nâng cao rồi mở phiên mới.' : summary.total ? 'Chọn “Tất cả giá” để xem cả giá khớp.' : 'Mở trang sản phẩm / tìm kiếm / giỏ hàng trên website test: khi website gọi API có giá, giá hiện ở đây.'}</div>`;
    // What the API returned, per response: product, field, price.
    const responses = ui.apiPrices || [];
    $('prices-api').innerHTML = responses.length ? responses.map((response, index) => `<details class="api-prices"${index === 0 ? ' open' : ''}><summary><b>${esc(response.method || 'GET')} ${esc(apiWhere(response.url))}</b> · ${esc(clock(response.captured_at))} · ${response.total} giá</summary><div class="table-scroll"><table class="params"><thead><tr><th>Sản phẩm</th><th>Trường trong API</th><th>Giá</th></tr></thead><tbody>${response.prices.map(entry => `<tr><td>${esc(entry.name || '—')}${entry.ids?.length ? `<br><small class="hint">${esc(entry.ids.join(' · '))}</small>` : ''}</td><td><code>${esc(entry.path)}</code></td><td><b>${esc(vnd(entry.value))}</b>${entry.currency ? ` <small class="hint">${esc(entry.currency)}</small>` : ''}</td></tr>`).join('')}</tbody></table></div>${response.total > response.prices.length ? `<p class="hint">Hiện ${response.prices.length} / ${response.total} giá của response này.</p>` : ''}</details>`).join('')
      : `<p class="hint">${off ? 'Phiên này không đọc API của website.' : 'Chưa có response API nào chứa giá.'}</p>`;
  }

  // ---- API Request/Response --------------------------------------------------
  // "(?:^|\.)api\.uat\.vinpearlota\.com(?:/|$)" is shown as api.uat.vinpearlota.com.
  const apiHostLabel = pattern => pattern.replace(/\(\?:\^\|\\\.\)|\(\?:\/\|\$\)/g, '').replace(/\\/g, '').replace(/[\^$]/g, '');
  const bytes = size => !size ? '' : size < 1024 ? `${size} B` : size < 1048576 ? `${(size / 1024).toFixed(1)} KB` : `${(size / 1048576).toFixed(1)} MB`;
  async function refreshApiCalls() {
    if (ui.apiCallsLoading || !ui.state) return;
    const q = $('apicalls-q')?.value.trim() || '', status = $('apicalls-status')?.value || '';
    const version = JSON.stringify([ui.state.session?.id, ui.state.apiCalls?.total, q, status]);
    if (version === ui.apiCallsVersion) return;
    ui.apiCallsLoading = true;
    try {
      const response = await fetch(`/api/api-calls?${new URLSearchParams({ q, status })}`, { signal: AbortSignal.timeout(10000) });
      if (!response.ok) throw new Error('Chưa tải được danh sách API.');
      const result = await response.json();
      if (result.session_id !== ui.apiCallsMeta?.session_id) ui.apiCallDetails.clear();
      ui.apiCalls = result.calls; ui.apiCallsMeta = result; ui.apiCallsVersion = version; ui.sig.apicalls = null; render();
    } catch (error) { showError(error.message); }
    finally { ui.apiCallsLoading = false; }
  }
  function apiBody(body) {
    if (!body) return '<p class="hint">Không có body.</p>';
    if (body.omitted) return `<p class="hint">${esc(body.omitted === 'credential_endpoint' ? 'Không lưu body của API đăng nhập / tài khoản.' : body.omitted === 'binary' ? `Dữ liệu nhị phân (${body.mime_type || ''}), không lưu.` : body.omitted === 'session_limit' ? 'Phiên đã đạt giới hạn dung lượng, không lưu body.' : body.omitted)}</p>`;
    const value = body.json !== undefined ? JSON.stringify(body.json, null, 2) : body.form ? JSON.stringify(body.form, null, 2) : body.text ?? '';
    return `${body.truncated ? `<p class="hint">Body dài ${bytes(body.size)}: chỉ hiện phần đầu.</p>` : ''}<pre class="activity-json" tabindex="0">${esc(value)}</pre>`;
  }
  function apiCallDetail(id) {
    const detail = ui.apiCallDetails.get(id);
    if (!detail) return '<p class="hint">Đang tải…</p>';
    if (detail.error) return `<p class="hint">${esc(detail.error)}</p>`;
    const { call, nearby } = detail;
    const headers = value => Object.keys(value || {}).length ? `<table class="params"><tbody>${Object.entries(value).map(([name, item]) => `<tr><td><code>${esc(name)}</code></td><td>${esc(item)}</td></tr>`).join('')}</tbody></table>` : '';
    return `<div class="toolbar"><button type="button" class="btn small" data-api-copy="${esc(id)}">Sao chép JSON</button><button type="button" class="btn small" data-api-download="${esc(id)}">Tải JSON</button></div>
      <p class="hint"><code>${esc(call.url)}</code>${call.page?.url ? `<br>Trang: ${esc(call.page.url)}` : ''}</p>
      ${Object.keys(call.query || {}).length ? `<h4>Query</h4><pre class="activity-json">${esc(JSON.stringify(call.query, null, 2))}</pre>` : ''}
      <h4>Request</h4>${headers(call.request?.headers)}${apiBody(call.request?.body)}
      <h4>Response ${call.response ? `· HTTP ${esc(call.response.status)}` : ''}</h4>${call.error ? `<div class="banner warn">${esc(call.error)}</div>` : ''}${call.incomplete ? `<div class="banner warn">${call.incomplete === 'no_response_before_stop' ? 'Đã dừng thu thập trước khi API trả response.' : 'Trang chưa đọc hết response sau 10 giây; body có thể chưa đầy đủ.'}</div>` : ''}${call.response ? `${headers(call.response.headers)}${apiBody(call.response.body)}` : '<p class="hint">Không có response.</p>'}
      <h4>Event tracking quanh lời gọi này <span class="hint">(5 giây trước khi gọi đến 5 giây sau khi xong)</span></h4>
      ${nearby.length ? `<ul class="log">${nearby.map(row => `<li>${esc(clock(row.captured_at))} · ${esc(SOURCE_TEXT[row.source] || row.source)} · <b>${esc(row.name)}</b> <button type="button" class="evlink" data-activity-id="${esc(row.evidence_id)}">Xem event</button></li>`).join('')}</ul>` : '<p class="hint">Không có event Google / Insider nào trong khoảng này.</p>'}`;
  }
  async function loadApiCall(id) {
    if (ui.apiCallDetails.has(id)) return;
    ui.apiCallDetails.set(id, null);
    try {
      const response = await fetch(`/api/api-call?id=${encodeURIComponent(id)}`, { signal: AbortSignal.timeout(10000) });
      const result = await response.json();
      ui.apiCallDetails.set(id, response.ok ? result : { error: result.error || 'Không tải được lời gọi API.' });
    } catch (error) { ui.apiCallDetails.set(id, { error: error.message }); }
    const host = document.querySelector(`[data-api-detail="${CSS.escape(id)}"]`);
    if (host) host.innerHTML = apiCallDetail(id);
  }
  function renderApiCalls(s) {
    const info = s.apiCalls || { total: 0, failed: 0 };
    setText('apicalls-count', String(info.total || 0));
    if (ui.tab !== 'apicalls') return;
    void refreshApiCalls();
    const host = $('apicalls-list'); if (!host) return;
    const sig = JSON.stringify([ui.apiCallsVersion, s.session?.id]); if (sig === ui.sig.apicalls) return; ui.sig.apicalls = sig;
    const meta = ui.apiCallsMeta, off = s.session && s.session.api_log === false;
    $('apicalls-summary').innerHTML = info.total ? `<div class="kv"><div><span>Lời gọi đã lưu</span><b>${info.total}</b></div><div><span>Lỗi (HTTP ≥ 400 / mạng)</span><b class="${info.failed ? 'text-fail' : ''}">${info.failed}</b></div><div><span>Đang hiện</span><b>${meta?.matched ?? 0}</b></div></div>` : '';
    const open = new Set($$('#apicalls-list details[open]').map(item => item.dataset.apiCall));
    const calls = ui.apiCalls || [];
    host.innerHTML = calls.length ? calls.map(call => `<details class="api-prices" data-api-call="${esc(call.evidence_id)}"${open.has(call.evidence_id) ? ' open' : ''}><summary><small>${esc(clock(call.captured_at))}</small> <b>${esc(call.method)}</b> <code>${esc(call.path)}</code> <span class="pill ${call.ok ? 'PASS' : 'FAIL'}">${esc(call.error ? 'Lỗi mạng' : call.status ?? '—')}</span>${call.incomplete ? ' <span class="pill warn">Chưa xong</span>' : ''} <small class="hint">${esc(call.host)}${call.duration_ms != null ? ` · ${call.duration_ms} ms` : ''}${call.response_size ? ` · ${bytes(call.response_size)}` : ''}</small></summary><div data-api-detail="${esc(call.evidence_id)}">${open.has(call.evidence_id) ? apiCallDetail(call.evidence_id) : ''}</div></details>`).join('')
      : `<div class="empty"><strong>${off ? 'Phiên này đã tắt Lưu API Request/Response' : info.total ? 'Không có lời gọi nào khớp bộ lọc' : 'Chưa có lời gọi API nào'}</strong>${off ? 'Bật lại ở bước 1 → Nâng cao rồi mở phiên mới.' : info.total ? 'Xoá ô tìm kiếm hoặc chọn “Tất cả”.' : `Thao tác trên website test: mọi lời gọi tới ${esc((meta?.patterns || s.apiCalls?.default_patterns || []).map(apiHostLabel).join(', '))} sẽ hiện ở đây.`}</div>`;
    for (const id of open) if (!ui.apiCallDetails.has(id)) void loadApiCall(id);
  }

  // ---- endpoints ----------------------------------------------------------
  function renderEndpoints(s) {
    const host = $('endpoints'); if (!host) return;
    const sig = JSON.stringify([s.patterns, s.discovered, s.running]); if (sig === ui.sig.endpoints) return; ui.sig.endpoints = sig;
    setText('endpoints-count', String(s.discovered?.length || 0));
    const discovered = s.discovered || [];
    host.innerHTML = `<h3 class="section-title">Endpoint nghi là tracking (chưa theo dõi)</h3>
      ${discovered.length ? `<div class="table-scroll"><table class="checks"><thead><tr><th>Host + path</th><th>Loại</th><th>Số lần</th><th></th></tr></thead><tbody>${discovered.map(d => `<tr><td><code>${esc(d.endpoint)}</code></td><td>${esc(d.method)} ${esc(d.resource_type || '')}</td><td>${d.count}</td><td><button type="button" class="btn small primary" data-add-endpoint="${esc(d.endpoint)}">Theo dõi</button></td></tr>`).join('')}</tbody></table></div>`
        : `<p class="hint">${ui.hooks.discoveryNote || (s.running ? 'Chưa thấy request nào giống tracking ngoài allowlist.' : 'Mở phiên để phát hiện endpoint tracking của website.')}</p>`}
      <h3 class="section-title">Đang theo dõi (${(s.patterns || []).length})</h3>
      <ul class="log">${(s.patterns || []).map(p => `<li><code>${esc(p)}</code></li>`).join('')}</ul>
      <p class="hint">Sửa danh sách ở bước 1 (vendor + endpoint bổ sung). Khi phiên đang chạy, bấm “Áp dụng” để theo dõi ngay từ request tiếp theo.</p>`;
  }
  async function addEndpoint(endpoint) {
    const pattern = `^${escapeRegex(endpoint)}$`;
    const area = $('patterns'); const lines = area.value.split('\n').map(l => l.trim()).filter(Boolean);
    if (!lines.includes(pattern)) area.value = [...lines, pattern].join('\n');
    saveSite();
    if (ui.state?.running) { await api('endpoints', { patterns: endpointPatterns() }, 'endpoints'); toast('Đã theo dõi endpoint; request mới sẽ được ghi.', 'ok'); }
    else toast('Đã thêm vào endpoint bổ sung; áp dụng khi mở phiên.', 'ok');
  }

  // ---- rule builder -------------------------------------------------------
  function flatten(value, prefix = '', depth = 0, out = []) {
    if (value && typeof value === 'object' && !Array.isArray(value) && depth < 4 && Object.keys(value).length) {
      for (const [key, child] of Object.entries(value)) flatten(child, prefix ? `${prefix}.${key}` : key, depth + 1, out);
    } else if (prefix) out.push([prefix, value]);
    return out;
  }
  function defaultField(path, value, event) {
    const leaf = path.split('.').at(-1);
    const protocol = event.layer === 'TRACKING_REQUEST' && event.source === 'GA4' && (GA4_PROTOCOL.has(path) || path.startsWith('_') || path.startsWith('up.'));
    const volatile = /^gtm\./.test(path) || /^(?:timestamp|ts|time|_et|event_id|eventId|uniqueEventId|session_id|client_id)$/i.test(leaf) || path === 'decode_status' || path === 'raw_hash';
    let op = 'exists', expected = '';
    // Evidence is redacted before storage, so a masked value can only be checked for presence.
    if (typeof value === 'string' && value.includes('[REDACTED')) return { path, value, include: !protocol && !volatile, op, expected, note: 'đã che dữ liệu nhạy cảm' };
    if (path === 'event' || path === 'event_name') { op = 'eq'; expected = value; }
    else if (typeof value === 'boolean') { op = 'eq'; expected = value; }
    else if (typeof value === 'number') { op = 'type'; expected = 'number'; }
    else if (Array.isArray(value)) { op = 'type'; expected = 'array'; }
    else if (typeof value === 'string') {
      if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) { op = 'regex'; expected = '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'; }
      else if (value.length && value.length <= 60) { op = 'eq'; expected = value; }
    }
    return { path, value, include: !protocol && !volatile && value !== undefined, op, expected, note: protocol ? 'tham số giao thức GA4' : volatile ? 'giá trị thay đổi mỗi lần' : '' };
  }
  function slug(text) { return String(text).normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '').toUpperCase().slice(0, 40) || 'EVENT'; }
  async function openBuilder(evidenceId) {
    const event = await fetchEvent(evidenceId);
    if (!event) return toast('Không đọc được event này.', 'error');
    if (event.payload?.decode_status === 'UNPARSED') toast('Payload không đọc được (UNPARSED): rule chỉ kiểm được số lượng event.');
    const fields = flatten(event.payload || {}).map(([path, value]) => defaultField(path, value, event));
    let id = `TC-${slug(event.event_name)}-${event.layer === 'JS_QUEUE' ? 'QUEUE' : 'REQ'}`;
    for (let n = 2; caseById(id); n++) id = `${id.replace(/-\d+$/, '')}-${n}`;
    const pairedRequest = event.layer === 'JS_QUEUE' && (ui.state?.eventSummary || []).some(g => g.layer === 'TRACKING_REQUEST' && g.event_name === event.event_name);
    ui.builder = { event, fields };
    const cases = ui.state?.cases || [];
    $('builder-body').innerHTML = `
      <div class="kv"><div><span>Event</span><b>${esc(event.event_name)}</b></div><div><span>Tầng · nguồn</span><b>${esc(LAYER_TEXT[event.layer] || event.layer)} · ${esc(event.source)}</b></div><div><span>Trang</span><b>${esc(short(hostOf(event.page?.url) + (() => { try { return new URL(event.page.url).pathname; } catch { return ''; } })(), 60))}</b></div></div>
      <div class="segmented" style="margin-top:12px"><button type="button" data-target-mode="new" aria-pressed="true">Case mới</button><button type="button" data-target-mode="append" aria-pressed="false" ${cases.length ? '' : 'disabled'}>Thêm vào case có sẵn</button></div>
      <div id="b-new" class="row"><div><label for="b-id">Mã case</label><input id="b-id" value="${esc(id)}"></div><div><label for="b-name">Tên case</label><input id="b-name" value="${esc(`${event.event_name} · ${LAYER_TEXT[event.layer] || event.layer}`)}"></div></div>
      <div id="b-append" class="hidden"><label for="b-case">Case</label><select id="b-case">${cases.map(c => `<option value="${esc(c.id)}" ${c.id === ui.selectedCase ? 'selected' : ''}>${esc(c.name)} (${esc(c.id)})</option>`).join('')}</select></div>
      <div class="row"><div><label for="b-min">Số lần tối thiểu</label><input id="b-min" type="number" min="0" value="1"></div><div><label for="b-max">Tối đa</label><input id="b-max" type="number" min="0" value="1"></div><div><label for="b-within">Trong vòng (ms, tuỳ chọn)</label><input id="b-within" type="number" min="0" placeholder="vd 10000"></div></div>
      <span class="label">Trường cần kiểm <span class="hint">(giá trị lấy từ event thật; đổi thành “lấy từ context” nếu giá trị thay đổi theo thao tác)</span></span>
      ${fields.length ? `<div class="table-scroll builder-table"><table class="checks"><thead><tr><th></th><th>Trường</th><th>Thực tế</th><th>Kiểm tra</th><th>Giá trị mong đợi</th></tr></thead><tbody>${fields.map((f, i) => `<tr data-field="${i}">
        <td><input type="checkbox" data-f="include" ${f.include ? 'checked' : ''} aria-label="Kiểm ${esc(f.path)}"></td>
        <td><code>${esc(f.path)}</code>${f.note ? `<br><small class="hint">${esc(f.note)}</small>` : ''}</td>
        <td><code>${esc(short(f.value, 50))}</code></td>
        <td><select data-f="op">${OPS.map(([op, label]) => `<option value="${op}" ${op === f.op ? 'selected' : ''}>${label}</option>`).join('')}</select></td>
        <td><input data-f="expected" value="${esc(typeof f.expected === 'string' ? f.expected : JSON.stringify(f.expected))}"></td></tr>`).join('')}</tbody></table></div>` : '<p class="hint">Event không có payload để kiểm; rule kiểm số lượng event.</p>'}
      ${pairedRequest ? '<label class="check" style="margin-top:10px"><input id="b-request" type="checkbox" checked> Thêm rule tầng Request cùng tên (kiểm request tracking được gửi)</label>' : ''}
      <label class="check" style="margin-top:10px"><input id="b-approve" type="checkbox" checked> Rule đã được QC xác nhận (bỏ tick nếu cần BA duyệt; kết quả sẽ là REVIEW)</label>
      <div id="b-error" class="field-error"></div>`;
    syncBuilderInputs();
    const dialog = $('builder'); if (!dialog.open) dialog.showModal();
  }
  function syncBuilderInputs() {
    for (const row of $$('#builder [data-field]')) {
      const op = row.querySelector('[data-f="op"]').value; const input = row.querySelector('[data-f="expected"]');
      const needsValue = !['exists', 'not_exists', 'ignore'].includes(op);
      input.disabled = !needsValue;
      if (op === 'ref' && !input.value.startsWith('context.')) input.value = `context.${ui.builder.fields[row.dataset.field].path.split('.').at(-1)}`;
      if (op === 'type' && !['string', 'number', 'boolean', 'array', 'object', 'null'].includes(input.value)) input.value = Array.isArray(ui.builder.fields[row.dataset.field].value) ? 'array' : typeof ui.builder.fields[row.dataset.field].value;
      input.placeholder = { ref: 'context.ten_truong', type: 'string | number | boolean | array', regex: '^...$', one_of: '["a","b"]' }[op] || '';
    }
  }
  function parseExpected(op, raw, actual) {
    if (op === 'ref' || op === 'regex' || op === 'type') return raw;
    if (op === 'one_of') { const list = JSON.parse(raw); if (!Array.isArray(list)) throw new Error('“một trong” cần mảng JSON, ví dụ ["a","b"].'); return list; }
    if (typeof actual === 'string') return raw;
    try { return JSON.parse(raw); } catch { return raw; }
  }
  function builderCase() {
    const { event, fields } = ui.builder; const approved = $('b-approve').checked;
    const min = Number($('b-min').value), max = Number($('b-max').value);
    if (!Number.isInteger(min) || !Number.isInteger(max) || min < 0 || max < min) throw new Error('Số lần cần là số nguyên, tối thiểu ≤ tối đa.');
    const ruleFields = {};
    for (const row of $$('#builder [data-field]')) {
      if (!row.querySelector('[data-f="include"]').checked) continue;
      const field = fields[row.dataset.field]; const op = row.querySelector('[data-f="op"]').value;
      const raw = row.querySelector('[data-f="expected"]').value;
      if (op === 'ref' && !/^context\.[\w.$-]+$/.test(raw)) throw new Error(`${field.path}: giá trị context cần dạng context.ten_truong.`);
      if (op === 'regex') { try { new RegExp(raw); } catch { throw new Error(`${field.path}: regex không hợp lệ.`); } }
      ruleFields[field.path] = ['exists', 'not_exists', 'ignore'].includes(op) ? { op } : { op, value: parseExpected(op, raw, field.value) };
    }
    const within = $('b-within').value.trim();
    const rule = { event_name: event.event_name, layer: event.layer, source: event.source, count: { min, max }, ...(within ? { within_ms: Number(within) } : {}), fields: ruleFields, needs_review: !approved };
    const rules = [rule];
    if ($('b-request')?.checked) rules.push({ event_name: event.event_name, layer: 'TRACKING_REQUEST', source: event.source, count: { min, max }, fields: {}, needs_review: !approved });
    const appending = document.querySelector('[data-target-mode="append"]')?.getAttribute('aria-pressed') === 'true';
    if (appending) {
      const base = structuredClone(caseById($('b-case').value));
      base.rules = [...(base.rules || []), ...rules]; base.needs_review = caseNeedsReview(base) || !approved;
      return base;
    }
    const id = $('b-id').value.trim(), name = $('b-name').value.trim();
    if (!id || !name) throw new Error('Nhập mã và tên case.');
    if (caseById(id)) throw new Error(`Đã có case ${id}; đổi mã hoặc chọn “Thêm vào case có sẵn”.`);
    return { id, name, source: event.source, flow: hostOf(event.page?.url) || undefined, description: `Tạo từ event thật ${event.evidence_id}.`, needs_review: !approved, rules };
  }
  async function saveBuilder() {
    let testCase;
    try { testCase = builderCase(); } catch (error) { $('b-error').textContent = error.message; return; }
    await api('save-case', { case: testCase }, 'save-case');
    $('builder').close(); ui.selectedCase = null; selectCase(testCase.id, { force: true }); setStage('spec', true); selectTab('spec');
    toast(ui.state?.running ? 'Đã lưu case. Chọn luồng rồi thao tác lại để kiểm tra.' : 'Đã lưu case vào imports/reviewed-cases.json.', 'ok');
  }

  // ---- log, reports, metrics ----------------------------------------------
  function renderLog(s) {
    const host = $('log'); if (!host) return;
    const sig = JSON.stringify(s.statuses); if (sig === ui.sig.log) return; ui.sig.log = sig;
    host.innerHTML = s.statuses.slice().reverse().map(x => `<li><time>${esc(clock(x.at))}</time><span>${esc(x.message)}</span></li>`).join('') || '<li><span class="hint">Ứng dụng sẵn sàng.</span></li>';
  }
  function renderReports(s) {
    const host = $('downloads'); if (!host) return;
    const sig = JSON.stringify([s.exported, s.runDir]); if (sig === ui.sig.reports) return; ui.sig.reports = sig;
    host.innerHTML = s.exported ? Object.entries(s.exported).map(([key, url]) => { const [title, note] = FILE_TEXT[key] || [key.toUpperCase(), '']; return `<a class="download" href="${esc(url)}"><strong>⬇ ${esc(title)}</strong><small>${esc(note)}</small></a>`; }).join('') : '';
    setText('run-dir', s.runDir ? `Thư mục phiên: ${s.runDir}` : '');
  }
  function renderMetrics(s) {
    // Events Google/Insider received, not every record captured (setup pushes, unsent pushes…).
    setText('event-count', String(s.delivery?.sent ?? s.eventCount));
    setText('kind-count', String(s.delivery?.kinds ?? s.eventSummary?.length ?? 0));
    const count = verdict => s.specCoverage ? s.specCoverage.rows.filter(row => ({ PASS: ['MATCH'], FAIL: ['MISMATCH', 'NOT_SENT'], REVIEW: ['REVIEW', 'PENDING'], NOT_EXECUTED: ['NOT_SEEN', 'NOT_SELECTED'] }[verdict] || []).includes(row.status)).length : s.results.filter(r => r.verdict === verdict).length;
    setText('pass-count', String(count('PASS'))); setText('fail-count', String(count('FAIL'))); setText('review-count', String(count('REVIEW'))); setText('notrun-count', String(count('NOT_EXECUTED')));
    setText('results-count', String(s.specCoverage?.selection.attempts.length || s.results.filter(r => r.step_id).length));
  }
  function renderControls(s, phase) {
    const busy = !!ui.busy; const set = (id, disabled) => { if ($(id)) $(id).disabled = disabled; };
    set('start', s.running || busy || s.closing); set('import', !!s.currentStep || (s.running && (s.steps?.length > 0 || s.specCoverage?.selection.attempts.length > 0)) || busy);
    set('save-case', !!s.currentStep || busy); set('delete-case', !!s.currentStep || busy || !ui.selectedCase);
    set('step-start', !s.running || !!s.currentStep || busy || !ui.selectedCase); set('step-complete', !s.currentStep || busy);
    set('finish', !s.running || ui.busy === 'finish-only' || s.closing); set('finish-export', !s.running || !!s.currentStep || busy); set('export', !s.session || busy); set('stop-session', !s.running || s.closing);
    $('apply-endpoints')?.classList.toggle('hidden', !s.running);
    $('recorder')?.classList.toggle('hidden', phase !== 'recording');
    $('step-idle')?.classList.toggle('hidden', phase === 'recording');
    if ($('context')) $('context').readOnly = phase === 'recording';
    for (const el of $$('[data-lock-running]')) el.disabled = s.running || busy;
    if (s.running && $('request-only')) $('request-only').checked = s.session?.capture_queues === false;
    if (phase === 'recording') setText('rec-count', String(s.stepEventCount ?? 0));
    $('review-banner')?.classList.toggle('hidden', !caseNeedsReview(caseById(ui.selectedCase)));
    $('ev-marked')?.closest('label')?.classList.toggle('hidden', !ui.marker);
    setText('marker-label', ui.marker ? `Mốc ${clock(new Date(ui.marker).toISOString())}` : '');
  }

  function render() {
    const s = ui.state; if (!s || ui.stopped) return;
    const phase = phaseOf(s);
    const indicator = $('board-capture-status');
    if (indicator) { indicator.textContent = s.running ? (s.session?.capture_queues === false ? 'Chỉ bắt request' : 'Đang thu thập') : s.session ? 'Đã kết thúc phiên' : 'Chưa mở phiên'; indicator.classList.toggle('active', !!s.running); }
    const casesKey = JSON.stringify([s.specSource, s.cases.length, s.cases.at(-1)?.id]);
    if (casesKey !== ui.casesKey) { ui.casesKey = casesKey; ui.details.clear(); ui.sig.events = null; }
    renderVendors(s); renderCases(s); renderFlow(s, phase); renderBar(s, phase); renderMetrics(s); renderControls(s, phase);
    if (Date.now() < ui.holdUntil) { clearTimeout(ui.holdTimer); ui.holdTimer = setTimeout(render, ui.holdUntil - Date.now() + 50); }
    else { renderResults(s); renderEvents(s); renderSpec(s); renderFiring(s); renderPrices(s); renderApiCalls(s); renderEndpoints(s); }
    renderLog(s); renderReports(s);
    ui.hooks.render?.(s, phase, ui);
  }

  // ---- tabs ---------------------------------------------------------------
  function selectTab(name) {
    ui.tab = name;
    for (const tab of $$('.tab')) tab.setAttribute('aria-selected', String(tab.dataset.tab === name));
    for (const panel of $$('.tabpanel')) panel.classList.toggle('hidden', panel.dataset.panel !== name);
    const names = { events: 'Event trực tiếp', spec: 'Đối chiếu đặc tả', results: 'Kết quả kiểm tra', firing: 'Kiểm tra cách bắn', prices: 'Giá so với API', apicalls: 'API Request/Response', tp2: 'TP2 ↔ API', endpoints: 'Endpoint tracking', log: 'Nhật ký phiên' };
    setText('board-title', names[name] || 'Event trực tiếp');
    for (const link of $$('[data-workspace-tab]')) {
      if (link.dataset.workspaceTab === name) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    }
    if (name === 'prices') { ui.sig.prices = null; render(); }
    if (name === 'apicalls') { ui.sig.apicalls = null; render(); }
  }

  function toggleSetup(collapsed = !document.body.classList.contains('setup-collapsed')) {
    document.body.classList.toggle('setup-collapsed', collapsed);
    $('setup-toggle')?.setAttribute('aria-expanded', String(!collapsed));
    const label = $('setup-toggle')?.querySelector('span'); if (label) label.textContent = collapsed ? 'Thiết lập phiên' : 'Ẩn thiết lập';
  }
  function revealSetup(stage) {
    toggleSetup(false);
    for (const item of $$('[data-stage]')) setStage(item.dataset.stage, item.dataset.stage === stage);
    document.querySelector(`[data-stage="${stage}"]`)?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    if (stage === 'session') $('url')?.focus({ preventScroll: true });
  }

  // ---- actions ------------------------------------------------------------
  function startPayload() {
    let url = $('url')?.value.trim(); if (!url) { $('url')?.focus(); throw new Error('Nhập URL website cần test, ví dụ www.website.vn'); }
    // People type "site.com/vi"; assume https when no scheme is given.
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(url)) url = `https://${url.replace(/^\/+/, '')}`;
    let parsed; try { parsed = new URL(url); } catch { throw new Error('URL chưa hợp lệ. Ví dụ: www.website.vn hoặc https://www.website.vn/'); }
    $('url').value = parsed.toString();
    if (!/^https?:$/.test(parsed.protocol)) throw new Error('URL cần dùng http hoặc https.');
    return { url: parsed.toString(), browser: $('browser')?.value || 'chrome', debugPort: Number($('debug-port')?.value) || undefined, captureQueues: !$('request-only')?.checked, compareApi: $('compare-api')?.checked ?? true, ...apiLogOptions(), endpointPatterns: endpointPatterns(), ...(ui.hooks.startPayload?.() || {}) };
  }
  const actions = {
    'view-spec': () => selectTab('spec'),
    'view-events': () => selectTab('events'),
    'export-tracking': () => {
      if (!ui.state?.session) throw new Error('Mở phiên và thu thập event trước khi xuất.');
      window.EventQAExports.open(false);
      for (const type of ['events', 'tracking', 'tp2', 'api']) $(`export-${type}`).checked = type === 'tracking';
    },
    'select-flow': () => openFlowPicker(),
    'close-flow-picker': () => $('comparison-flow-dialog').close(),
    'close-event-picker': () => $('comparison-event-dialog').close(),
    'retest-flow': async () => { await api('comparison/retest', {}, 'comparison-retest'); selectTab('spec'); toast('Đã bắt đầu lượt mới. Thực hiện lại thao tác trên website để thu event mới.', 'ok'); },
    'pause-comparison': async () => { await api('comparison/stop', {}, 'comparison-stop'); toast('Đã tạm dừng đối chiếu. Phiên vẫn thu thập event.'); },
    start: async () => {
      const payload = startPayload(); saveSite();
      await api('start', payload, 'start'); ui.marker = null; selectTab('events');
      if (ui.state?.navigationError) return showError(`${ui.state.navigationError} Phiên vẫn mở: sửa URL ngay trong cửa sổ test, hoặc dừng phiên và nhập lại.`);
      toast(ui.state?.cases.length ? 'Đã mở trình duyệt test. Đăng nhập nếu cần, rồi chọn luồng trong bảng Đối chiếu đặc tả.' : 'Đã mở trình duyệt test. Đăng nhập nếu cần và thao tác; event hiện ở tab Event trực tiếp.', 'ok');
    },
    'step-start': async () => {
      const parsed = validateContext(); if (!parsed.ok) throw new Error('Context JSON chưa hợp lệ.');
      if (!ui.selectedCase) throw new Error('Chọn test case trước.');
      ui.contexts.set(ui.selectedCase, $('context').value);
      await api('step/start', { testCaseId: ui.selectedCase, context: parsed.value }, 'step-start');
      ui.marker = Date.parse(ui.state.currentStep.started_at);
      toast('Đang ghi bước. Sang trình duyệt test để thao tác.', 'ok');
    },
    'step-complete': async () => {
      const result = await api('step/complete', {}, 'step-complete');
      const last = (result.results || []).filter(r => r.step_id).at(-1);
      if (last) toast(`Kết quả: ${VERDICT_TEXT[last.verdict] || last.verdict}`, last.verdict === 'PASS' ? 'ok' : last.verdict === 'FAIL' ? 'error' : '');
      selectTab('results');
    },
    'set-marker': () => {
      ui.marker = Date.now(); if ($('ev-marked')) $('ev-marked').checked = true;
      selectTab('events'); ui.sig.events = null; render();
      toast('Đã đặt mốc. Thao tác trên website; chỉ event mới được hiển thị.', 'ok');
    },
    'clear-marker': () => { ui.marker = null; if ($('ev-marked')) $('ev-marked').checked = false; ui.sig.events = null; render(); },
    'apply-endpoints': async () => { saveSite(); await api('endpoints', { patterns: endpointPatterns() }, 'endpoints'); toast('Đã cập nhật allowlist cho request mới.', 'ok'); },
    'use-demo': async () => {
      $('url').value = `${location.origin}/demo`;
      if (!ui.state?.running) await api('demo-spec', {}, 'demo-spec');
      resetSelection(); setStage('session', true); toast('Đã chọn trang demo nội bộ và 3 case mẫu.', 'ok');
    },
    finish: async () => {
      if (window.EventQAExports) return window.EventQAExports.open(true);
      const aiNotes = $('report-ai-notes')?.checked !== false;
      toast(aiNotes && ui.state?.ai?.enabled ? 'Đang kết thúc phiên và tạo báo cáo kèm nhận xét AI…' : 'Đang kết thúc phiên và xuất báo cáo…');
      await api('finish', { aiNotes }, 'finish'); toast('Đã kết thúc phiên và xuất báo cáo.', 'ok');
    },
    // An expected event typed by hand: the server reads the pasted sample like an Excel row.
    'manual-case': async () => {
      const result = await api('manual-case', { event_name: $('manual-event').value, source: $('manual-source').value, flow: $('manual-flow').value, description: $('manual-description').value, sample: $('manual-sample').value }, 'manual-case');
      const added = result.manualCase; if (!added) return;
      $('manual-result').innerHTML = `<div class="banner info"><p><b>Đã thêm ${esc(added.event_name)}</b>${added.flow ? ` · ${esc(added.flow)}` : ''} (${esc(SOURCE_TEXT[added.source] || added.source)}): sẽ kiểm ${added.fields.length} trường ${added.fields.slice(0, 8).map(field => `<code>${esc(field)}</code>`).join(', ')}${added.fields.length > 8 ? '…' : ''}. Sửa cách kiểm ở “Xem / sửa rule” nếu cần.</p>${added.warnings.length ? `<p class="hint">${added.warnings.map(esc).join('<br>')}</p>` : ''}</div>`;
      $('manual-sample').value = ''; $('manual-event').value = '';
      toast(`Đã thêm ${added.event_name} vào đặc tả. Chọn luồng ở bảng Đối chiếu đặc tả để kiểm tra.`, 'ok');
    },
    export: async () => {
      if (window.EventQAExports) return window.EventQAExports.open(false);
      const aiNotes = $('report-ai-notes')?.checked !== false;
      toast(aiNotes && ui.state?.ai?.enabled ? 'Đang tạo báo cáo kèm nhận xét AI…' : 'Đang xuất báo cáo…');
      await api('export', { aiNotes }, 'export'); toast('Đã xuất báo cáo hiện tại.', 'ok');
    },
    'finish-only': async () => { await api('finish', { exportReport: false, aiNotes: false }, 'finish-only'); toast('Đã kết thúc và lưu bằng chứng. Chưa tạo báo cáo.', 'ok'); },
    'stop-session': async () => {
      if (ui.state?.currentStep && !confirm('Bước đang ghi sẽ được giữ REVIEW. Dừng phiên?')) return;
      await api('stop-session', {}, 'stop-session'); toast('Đã dừng phiên và lưu bằng chứng.');
    },
    import: async () => {
      const file = $('spec-path').value.trim().replace(/^"(.*)"$/, '$1'); if (!file) throw new Error('Nhập đường dẫn file XLSX hoặc JSON.');
      $('spec-path').value = file; const result = await api('import', { path: file, sheet: $('sheet')?.value.trim() }, 'import');
      if ($('spec-file-status')) $('spec-file-status').textContent = `Đã nhập ${result.cases.length} dòng. ` + (result.cases.some(c => c.payload_format === 'default_custom_parameters') ? 'Mẫu AppOTA: xem lưu ý cấu trúc và bảng chi tiết.' : 'Mở tab Đối chiếu đặc tả để xem chi tiết từng event.');
      resetSelection(); selectTab('spec'); toast(`Đã nhập ${ui.state?.cases.length ?? ''} dòng đặc tả. Chọn luồng kiểm tra để bắt đầu đối chiếu.`, 'ok');
    },
    'save-case': async () => {
      const parsed = parseJson('case-json', 'case-json-error'); if (!parsed.ok) throw new Error('Rule JSON chưa hợp lệ.');
      const testCase = parsed.value; const approved = !!$('approve')?.checked;
      testCase.needs_review = !approved; for (const rule of testCase.rules || []) rule.needs_review = !approved;
      await api('save-case', { case: testCase }, 'save-case'); ui.selectedCase = testCase.id; loadRuleEditor(caseById(testCase.id));
      toast(approved ? 'Đã lưu rule đã duyệt.' : 'Đã lưu rule (vẫn cần duyệt).', 'ok');
    },
    'delete-case': async () => {
      if (!ui.selectedCase || !confirm(`Xoá case ${ui.selectedCase}?`)) return;
      await api('delete-case', { id: ui.selectedCase }, 'delete-case'); resetSelection(); toast('Đã xoá case.', 'ok');
    },
    'builder-save': () => saveBuilder(),
    'builder-json': () => {
      let testCase; try { testCase = builderCase(); } catch (error) { $('b-error').textContent = error.message; return; }
      $('builder').close(); window.EventQA.loadIntoRuleEditor(testCase);
    },
    'builder-close': () => $('builder').close(),
    'events-back': () => { ui.view = 'groups'; clearEventFilters(); },
    'events-clear': () => clearEventFilters(),
    shutdown: async () => {
      if (!confirm(ui.state?.running ? 'Phiên đang chạy sẽ được lưu rồi tắt ứng dụng. Tiếp tục?' : 'Tắt ứng dụng?')) return;
      const result = await api('shutdown', {}, 'shutdown'); ui.stopped = true;
      document.body.innerHTML = `<div class="stopped-screen"><h1>Đã tắt EventQA</h1><p>${esc(result.message || '')}</p><p class="hint">Có thể đóng tab này. Báo cáo nằm trong thư mục <code>runs</code>. Chạy lại file <code>start.cmd</code> để mở lại.</p></div>`;
    },
  };

  function closeSheetPicker() {
    $('sheet-picker-popup')?.classList.add('hidden'); $('sheet-picker-button')?.setAttribute('aria-expanded', 'false');
  }
  function renderSheetChoices() {
    const normalize = value => value.normalize('NFD').replace(/\p{M}/gu, '').replace(/đ/gi, 'd').toLowerCase();
    const query = normalize($('sheet-search').value.trim()), selected = $('sheet').value;
    const names = (ui.sheetNames || []).filter(name => normalize(name).includes(query));
    $('sheet-choices').innerHTML = names.map(name => `<button type="button" role="option" aria-selected="${name === selected}" data-sheet-choice="${esc(name)}">${esc(name)}</button>`).join('') || '<p class="hint">Không tìm thấy sheet phù hợp.</p>';
  }
  function selectSheet(name) {
    $('sheet').value = name; $('sheet-select').value = name; $('sheet-selected').textContent = name || 'Tự nhận diện sheet';
  }
  function bindCommon() {
    // Keep the rule editor available as an advanced tool; manual per-step controls are retired.
    const editor = $('rule-editor'), specSetup = document.querySelector('[data-stage="spec"] .stage-body');
    if (editor && specSetup) specSetup.append(editor);
    $('activity-close')?.addEventListener('click', () => $('activity-dialog').close());
    $('activity-more')?.addEventListener('click', run(() => refreshActivity(true)));
    for (const id of ['activity-from', 'activity-to']) $(id)?.addEventListener('input', () => { ui.sig.events = null; render(); });
    document.addEventListener('visibilitychange', () => { if (!document.hidden) void refresh(); });
    $('setup-toggle')?.addEventListener('click', () => toggleSetup());
    $('spec-detail-close')?.addEventListener('click', () => $('spec-detail-dialog').close());
    $('sheet-select')?.addEventListener('change', () => selectSheet($('sheet-select').value));
    $('sheet')?.addEventListener('input', () => { $('sheet-selected').textContent = $('sheet').value || 'Tự nhận diện sheet'; });
    $('sheet-picker-button')?.addEventListener('click', () => {
      if ($('sheet-picker-button').getAttribute('aria-expanded') === 'true') return closeSheetPicker();
      $('sheet-search').value = ''; renderSheetChoices(); $('sheet-picker-popup').classList.remove('hidden');
      const box = $('sheet-picker-button').getBoundingClientRect(), above = box.top - 12, below = innerHeight - box.bottom - 12, upward = below < 300 && above > below;
      $('sheet-picker-popup').classList.toggle('above', upward);
      $('sheet-picker-popup').style.setProperty('--sheet-list-height', `${Math.max(80, Math.min(240, (upward ? above : below) - 76))}px`);
      $('sheet-picker-button').setAttribute('aria-expanded', 'true'); $('sheet-search').focus({ preventScroll: true });
    });
    $('sheet-search')?.addEventListener('input', renderSheetChoices);
    $('sheet-picker')?.addEventListener('keydown', event => {
      if ($('sheet-picker-popup').classList.contains('hidden')) return;
      if (event.key === 'Escape') { event.preventDefault(); closeSheetPicker(); $('sheet-picker-button').focus(); }
      if (['ArrowDown', 'ArrowUp'].includes(event.key)) {
        event.preventDefault(); const buttons = [...$('sheet-choices').querySelectorAll('button')];
        const current = buttons.indexOf(document.activeElement), next = current < 0 ? event.key === 'ArrowDown' ? 0 : buttons.length - 1 : (current + (event.key === 'ArrowDown' ? 1 : -1) + buttons.length) % buttons.length;
        buttons[next]?.focus();
      }
    });
    document.addEventListener('click', event => {
      const choice = event.target.closest('[data-sheet-choice]');
      if (choice) { selectSheet(choice.dataset.sheetChoice); closeSheetPicker(); $('sheet-picker-button').focus({ preventScroll: true }); }
      else if (!event.target.closest('#sheet-picker')) closeSheetPicker();
    });
    $('spec-file')?.addEventListener('change', run(async () => {
      const file = $('spec-file').files[0]; if (!file) return;
      if (file.size > 3 * 1024 * 1024) throw new Error('Chọn file nhỏ hơn 3 MB.');
      const content = await new Promise((resolve, reject) => { const reader = new FileReader(); reader.onerror = reject; reader.onload = () => resolve(String(reader.result).split(',')[1]); reader.readAsDataURL(file); });
      const uploaded = await api('spec-upload', { name: file.name, content }, 'spec-upload');
      $('spec-path').value = uploaded.path;
      const names = uploaded.sheets.map(s => s.name);
      ui.sheetNames = names; closeSheetPicker();
      const selected = names.includes('R1511') ? 'R1511' : names.includes('Tổng hợp Event tracking') ? 'Tổng hợp Event tracking' : names[0] || '';
      $('sheet-select').innerHTML = names.map(name => `<option>${esc(name)}</option>`).join('') || '<option>JSON — không có sheet</option>';
      $('sheet-select').disabled = !names.length; $('sheet-select').value = selected;
      $('sheet-picker-button').disabled = !names.length; $('sheet-selected').textContent = selected || 'JSON · không có sheet';
      $('sheet-list').innerHTML = names.map(name => `<option value="${esc(name)}"></option>`).join('');
      $('sheet').value = selected;
      $('spec-file-status').textContent = `${file.name} · ${names.length} sheet. Đã chọn ${selected || 'JSON'}; bấm Nhập file để áp dụng.`;
    }));
    document.addEventListener('pointerdown', event => { if (event.target.closest('.board')) ui.holdUntil = Date.now() + 700; }, true);
    $('ev-pending')?.addEventListener('click', () => { ui.openEvents.clear(); for (const d of $$('#events details[open]')) d.open = false; ui.sig.events = null; render(); });
    document.addEventListener('click', event => {
      const target = event.target.closest('[data-action], [data-case], [data-evidence], .stage-head, .tab, [data-browser], [data-url], [data-view], [data-build], [data-group-view], [data-add-endpoint], [data-target-mode], [data-expand], [data-spec-detail], [data-workspace-tab], [data-setup-stage], [data-activity-id], [data-activity-view], [data-choose-flow], [data-change-comparison-event], [data-choose-comparison-event], [data-preview-comparison], button[data-comparison-mode]');
      if (!target || target.disabled) return;
      const d = target.dataset;
      if (d.chooseFlow) return run(async () => { await api('comparison/start', { flow: d.chooseFlow }, 'comparison-start'); $('comparison-flow-dialog').close(); for (const id of ['spec-flow', 'spec-status', 'spec-platform', 'spec-search']) $(id).value = ''; ui.sig.spec = null; selectTab('spec'); toast('Đã bắt đầu đối chiếu. Thao tác luồng này trên website để nhận event mới.', 'ok'); })();
      if (d.comparisonMode) {
        const view = target.closest('.event-comparison'); view.dataset.comparisonMode = d.comparisonMode;
        for (const button of $$('button[data-comparison-mode]', view)) button.setAttribute('aria-pressed', String(button === target)); return;
      }
      if (d.previewComparison) return run(() => previewComparison(d.previewComparison))();
      if (d.changeComparisonEvent) return run(() => openEventPicker(d.changeComparisonEvent))();
      if (d.chooseComparisonEvent) return run(async () => {
        if (ui.busy) return;
        const caseId = eventChoices.case_id; target.disabled = true;
        try {
          await api('comparison/event', { case_id: caseId, evidence_id: d.chooseComparisonEvent === 'auto' ? null : d.chooseComparisonEvent }, 'comparison-event');
          $('comparison-event-dialog').close(); await openSpecDetail(caseId); toast('Đã cập nhật event đối chiếu.', 'ok');
        } finally { if (target.isConnected) target.disabled = false; }
      })();
      if (d.activityId) return run(() => openActivity(d.activityId))();
      if (d.activityView) {
        for (const button of $$('[data-activity-view]')) button.setAttribute('aria-pressed', String(button === target));
        for (const panel of $$('[data-activity-panel]')) panel.classList.toggle('hidden', panel.dataset.activityPanel !== d.activityView);
        return;
      }
      if (d.workspaceTab) { selectTab(d.workspaceTab); if (d.workspaceTab === 'spec' && !ui.state?.cases.length) revealSetup('spec'); return; }
      if (d.setupStage) return revealSetup(d.setupStage);
      if (d.specDetail) return run(() => openSpecDetail(d.specDetail))();
      if (d.action && actions[d.action]) return run(actions[d.action])();
      if (d.action && ui.hooks.actions?.[d.action]) return run(() => ui.hooks.actions[d.action](target))();
      if (d.case) return selectCase(d.case);
      if (d.evidence) return jumpToEvidence(d.evidence);
      if (d.build) return run(() => openBuilder(d.build))();
      if (d.groupView) return showGroup(d.groupView);
      if (d.expand) { ui.expandedGroup = ui.expandedGroup === d.expand ? null : d.expand; ui.sig.events = null; return render(); }
      if (d.addEndpoint) return run(() => addEndpoint(d.addEndpoint))();
      if (d.view) { ui.view = d.view; ui.sig.events = null; if (d.view === 'stream' && ui.state?.eventsCompact) return void refresh(); return render(); }
      if (d.url) { $('url').value = d.url; ui.hooks.urlChanged?.(); return; }
      if (d.browser) return setBrowser(d.browser);
      if (d.targetMode) {
        for (const b of $$('[data-target-mode]')) b.setAttribute('aria-pressed', String(b === target));
        $('b-new').classList.toggle('hidden', d.targetMode !== 'new'); $('b-append').classList.toggle('hidden', d.targetMode === 'new'); return;
      }
      if (target.classList.contains('stage-head')) { const stage = target.closest('[data-stage]'); return setStage(stage.dataset.stage, !stage.classList.contains('open')); }
      if (target.classList.contains('tab')) return selectTab(d.tab);
    });
    $('builder')?.addEventListener('change', event => { if (event.target.matches('[data-f="op"]')) syncBuilderInputs(); });
    $('context')?.addEventListener('input', () => { validateContext(); if (ui.selectedCase) ui.contexts.set(ui.selectedCase, $('context').value); });
    $('case-json')?.addEventListener('input', () => parseJson('case-json', 'case-json-error'));
    $('context-format')?.addEventListener('click', () => { const parsed = validateContext(); if (parsed.ok) { $('context').value = JSON.stringify(parsed.value, null, 2); ui.contexts.set(ui.selectedCase, $('context').value); } });
    $('context-reset')?.addEventListener('click', () => { ui.contexts.delete(ui.selectedCase); selectCase(ui.selectedCase, { force: true }); });
    $('rule-reset')?.addEventListener('click', () => loadRuleEditor(caseById(ui.selectedCase)));
    for (const id of ['ev-layer', 'ev-source', 'ev-search', 'ev-marked', 'ev-system', 'ev-unsent']) $(id)?.addEventListener('input', () => { if (!['ev-marked', 'ev-system', 'ev-unsent'].includes(id)) ui.groupFilter = null; ui.sig.events = null; render(); });
    for (const id of ['spec-flow', 'spec-platform', 'spec-status', 'spec-search']) $(id)?.addEventListener('input', () => { ui.sig.spec = null; render(); });
    $('comparison-flow-search')?.addEventListener('input', renderFlowChoices);
    $('comparison-event-search')?.addEventListener('input', renderEventChoices);
    $('firing-status')?.addEventListener('input', () => { ui.sig.firing = null; render(); });
    $('prices-status')?.addEventListener('input', () => { ui.sig.prices = null; render(); });
    for (const id of ['apicalls-q', 'apicalls-status']) $(id)?.addEventListener('input', () => { ui.apiCallsVersion = null; render(); });
    $('apicalls-list')?.addEventListener('toggle', event => {
      const id = event.target.dataset?.apiCall; if (!id || !event.target.open) return;
      const host = event.target.querySelector('[data-api-detail]');
      if (host) host.innerHTML = apiCallDetail(id);
      void loadApiCall(id);
    }, true);
    $('apicalls-list')?.addEventListener('click', event => run(async () => {
      const copy = event.target.closest('[data-api-copy]'), download = event.target.closest('[data-api-download]');
      const id = copy?.dataset.apiCopy ?? download?.dataset.apiDownload; if (!id) return;
      const call = ui.apiCallDetails.get(id)?.call; if (!call) return;
      if (copy) {
        try { await navigator.clipboard.writeText(JSON.stringify(call, null, 2)); toast('Đã sao chép request/response.', 'ok'); }
        catch { throw new Error('Trình duyệt chưa cho phép sao chép. Dùng nút Tải JSON.'); }
      } else {
        const url = URL.createObjectURL(new Blob([JSON.stringify(call, null, 2)], { type: 'application/json' }));
        const link = document.createElement('a'); link.href = url; link.download = `${id}.json`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
      }
    })());
    $('events')?.addEventListener('toggle', event => {
      const id = event.target.dataset?.ev; if (!id) return;
      if (event.target.open) { ui.openEvents.add(id); const host = event.target.querySelector(`[data-detail="${CSS.escape(id)}"]`); if (host && !host.innerHTML.trim()) host.innerHTML = detailContent(id); }
      else ui.openEvents.delete(id);
    }, true);
    $('spec-path')?.addEventListener('keydown', event => { if (event.key === 'Enter') run(actions.import)(); });
    $('url')?.addEventListener('keydown', event => { if (event.key === 'Enter' && !ui.state?.running) run(actions.start)(); });
    $('url')?.addEventListener('input', () => ui.hooks.urlChanged?.());
    $('vendors')?.addEventListener('change', saveSite);
    $('vendors-more')?.addEventListener('change', saveSite);
    $('compare-api')?.addEventListener('change', saveSite);
    $('log-api')?.addEventListener('change', saveSite);
    $('api-patterns')?.addEventListener('change', saveSite);
    $('patterns')?.addEventListener('change', saveSite);
  }

  window.EventQA = {
    boot({ token, mode, hooks = {} }) {
      ui.token = token; ui.mode = mode; ui.hooks = hooks;
      bindCommon(); selectTab('events'); restoreSite();
      refresh(); setInterval(refresh, 1500); setInterval(tickTimers, 1000);
    },
    api, toast, showError, esc, short, run, selectTab, refresh, get state() { return ui.state; }, get selectedCase() { return ui.selectedCase; },
    loadIntoRuleEditor(testCase) {
      if (!$('case-json')) return;
      toggleSetup(false);
      $('case-json').value = JSON.stringify(testCase, null, 2); if ($('approve')) $('approve').checked = !testCase.needs_review;
      if ($('rule-title')) $('rule-title').textContent = `${testCase.id || ''} (chưa lưu)`;
      revealSetup('spec'); $('rule-editor').open = true; $('case-json').scrollIntoView({ block: 'center', behavior: 'smooth' });
    },
  };
})();
