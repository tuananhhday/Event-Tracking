EventQA portable - Windows 64-bit

1. Extract the ENTIRE ZIP to a writable folder (for example Documents\EventQA).
2. Open START_PORTABLE.cmd. Do not run it from inside the ZIP viewer.
3. Keep the command window open. The guided tracking page opens directly.
4. Upload requirements, enter the Web/UAT URL and choose one business flow.
5. Follow each instruction: Start step, perform the action, then Check.
6. See expected/actual events and params; export a report if needed.
7. End/export before closing. Use STOP_PORTABLE.cmd to stop safely.
Vietnamese quick guide: HUONG_DAN.txt.

No Node installation, npm command, admin rights or package download is needed.
Includes official Node.js 24.19.0 Windows x64 and locked JavaScript dependencies.
Requires an existing Chrome/Edge and permission to execute node.exe and CMD.
Company application-control and browser debugging policies still apply. If
execution is blocked, ask IT to approve it; this package does not bypass policy.
External websites still need normal company network access.

The default guided flow uses CDP. AI needs your own OpenRouter credentials.
Open AI settings, paste your key and click Save key locally.
The key is kept in .env on YOUR computer, works immediately and after restart.
It is never bundled in this public ZIP. No configuration file editing is needed.
AI tries all eligible free models first, then the cheapest eligible paid model
if enabled. Total estimated cost is capped at USD 0.01 per task.
Advanced diagnostic screens remain separate. Proxy needs Python/mitmproxy
separately; neither is bundled. Session data and reports stay in runs/ locally.
Choose your XLSX file first. For WebOTA, select Tong hop Event tracking
(the Vietnamese sheet name is selected automatically). AppOTA R1511 is a
separate mobile reference; do not apply its device fields to Web by default.
The specification tab shows exact event names, descriptions and payload samples
beside real evidence. AppOTA sample shapes may differ from website events.
AI arranges the selected requirements into manual test steps. It cannot invent
expected events or params. If AI is unavailable, file-derived guidance is labeled.
Unreviewed requirements and dynamic values without context remain REVIEW.

Each action shows expected versus actual events and parameter differences.
Choose Golf, Flight, Hotel or another flow. Queue requirements compare against
the actual queue; SDK and request evidence are supplementary observations.
Lifecycle chatter does not become business events. Expand evidence to see raw
payloads and field origins. Missing values are never filled from samples.
Optional failure branches can be skipped and remain not executed.
For a website that cannot be operated with queue capture, end the session,
enable request-only capture in CDP, then open a new session. This does not
inject JavaScript queue hooks; queue checks are REVIEW, not a false missing event.
Do not commit runs/, profiles/, imports/ or credentials to GitHub.

Built on Linux; Windows execution has not been validated on a Windows machine.
The application CDP smoke test and report exports were validated on Linux.
Node's runtime license is in runtime/LICENSE.txt. Dependency licenses remain
in node_modules. Source files are included for inspection.
