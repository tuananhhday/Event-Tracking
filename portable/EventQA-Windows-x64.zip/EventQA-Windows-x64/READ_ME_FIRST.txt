EventQA portable - Windows 64-bit

1. Extract the ENTIRE ZIP to a writable folder (for example Documents\EventQA).
2. Open START_PORTABLE.cmd. Do not run it from inside the ZIP viewer.
3. Keep the command window open. The dashboard opens in your default browser.
4. Select Chrome or Edge already installed on your computer.
5. End/export the session before closing. Use STOP_PORTABLE.cmd to stop safely.

No Node installation, npm command, admin rights or package download is needed.
Includes official Node.js 24.19.0 Windows x64 and locked JavaScript dependencies.
Requires an existing Chrome/Edge and permission to execute node.exe and CMD.
Company application-control and browser debugging policies still apply. If
execution is blocked, ask IT to approve it; this package does not bypass policy.
External websites still need normal company network access.

This bundle supports CDP without AI. It does not include Python/mitmproxy or
OpenRouter credentials. Session data and reports stay in runs/ on this machine.
Do not commit runs/, profiles/, imports/ or credentials to GitHub.

Built on Linux; Windows execution has not been validated on a Windows machine.
The application CDP smoke test and report exports were validated on Linux.
Node's runtime license is in runtime/LICENSE.txt. Dependency licenses remain
in node_modules. Source files are included for inspection.
