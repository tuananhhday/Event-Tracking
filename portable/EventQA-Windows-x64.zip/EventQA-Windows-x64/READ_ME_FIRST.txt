EventQA portable - Windows 64-bit

1. Extract the ENTIRE ZIP to a writable folder (for example Documents\EventQA).
2. Open START_PORTABLE.cmd. Do not run it from inside the ZIP viewer.
3. Keep the command window open. A web page opens with three mode choices.
4. Select Chrome or Edge already installed on your computer.
5. End/export the session before closing. Use STOP_PORTABLE.cmd to stop safely.

No Node installation, npm command, admin rights or package download is needed.
Includes official Node.js 24.19.0 Windows x64 and locked JavaScript dependencies.
Requires an existing Chrome/Edge and permission to execute node.exe and CMD.
Company application-control and browser debugging policies still apply. If
execution is blocked, ask IT to approve it; this package does not bypass policy.
External websites still need normal company network access.

CDP runs immediately. AI features need your own OpenRouter credentials.
Choose CDP + AI, open the AI tab, paste your key and click Save key locally.
The key is kept in .env on YOUR computer, works immediately and after restart.
It is never bundled in this public ZIP. No configuration file editing is needed.
AI tries all eligible free models first, then the cheapest eligible paid model
if enabled. Total estimated cost is capped at USD 0.01 per task.
Proxy needs Python/mitmproxy separately; neither is bundled. The mode selector
explains these requirements. Session data and reports stay in runs/ locally.
Choose your XLSX file in step 2. For WebOTA, select Tong hop Event tracking
(the Vietnamese sheet name is selected automatically). AppOTA R1511 is a
separate mobile reference; do not apply its device fields to Web by default.
The specification tab shows exact event names, descriptions and payload samples
beside real evidence. AppOTA sample shapes may differ from website events.
The AI tab can load a selected event's requirements from your imported workbook.
Unreviewed requirements and dynamic values without context remain REVIEW.

The default Events view is Activity / JSON: one row per observed event.
Choose Golf, Flight, Hotel or another flow. Outgoing requests, JS queues and
SDK observations are separate selections. SDK lifecycle chatter is hidden.
Open a row to see, copy or download event/default_parameters/custom_parameters.
The Raw Payload tab retains original captured field names. Missing mobile app
attributes are never filled from the workbook. Sensitive fields are masked.
For a website that cannot be operated with queue capture, end the session,
enable request-only capture in CDP, then open a new session. This does not
inject JavaScript queue hooks; queue checks are REVIEW, not a false missing event.
Do not commit runs/, profiles/, imports/ or credentials to GitHub.

Built on Linux; Windows execution has not been validated on a Windows machine.
The application CDP smoke test and report exports were validated on Linux.
Node's runtime license is in runtime/LICENSE.txt. Dependency licenses remain
in node_modules. Source files are included for inspection.
